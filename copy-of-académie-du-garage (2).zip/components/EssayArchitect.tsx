
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { EssayPlan } from '../types';

interface Critique {
  weaknesses: string[];
  counterArguments: string[];
  improvements: string[];
  gradeEstimate: string;
}

const EXAMPLE_TOPICS = [
  "La souveraineté de l'État face à la mondialisation",
  "Peut-on gouverner sans le peuple ?",
  "Justice sociale et liberté individuelle : sont-elles conciliables ?",
  "Le rôle des partis politiques en démocratie contemporaine"
];

const EssayArchitect: React.FC = () => {
  const [subject, setSubject] = useState('');
  const [plan, setPlan] = useState<EssayPlan | null>(null);
  const [loading, setLoading] = useState(false);
  const [critique, setCritique] = useState<Critique | null>(null);
  const [critiqueLoading, setCritiqueLoading] = useState(false);

  const generatePlan = async (selectedSubject?: string) => {
    const finalSubject = selectedSubject || subject;
    if (!finalSubject) return;
    
    if (selectedSubject) {
      setSubject(selectedSubject);
    }

    setLoading(true);
    setPlan(null); // Reset previous plan
    setCritique(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: `En tant que professeur à Sciences Po, génère un plan de dissertation détaillé pour le sujet suivant : "${finalSubject}". Réponds uniquement en JSON respectant le format spécifié.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              title: { type: Type.STRING },
              problematic: { type: Type.STRING },
              outline: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    part: { type: Type.STRING },
                    subparts: {
                      type: Type.ARRAY,
                      items: { type: Type.STRING }
                    }
                  }
                }
              },
              conclusion: { type: Type.STRING }
            },
            required: ["title", "problematic", "outline", "conclusion"]
          }
        }
      });

      const parsedPlan = JSON.parse(response.text || "{}");
      setPlan(parsedPlan);
    } catch (error) {
      console.error("Erreur JSON ou API:", error);
    } finally {
      setLoading(false);
    }
  };

  const generateCritique = async () => {
    if (!plan) return;
    setCritiqueLoading(true);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: `Agis comme un examinateur de concours très sévère. Critique ce plan de dissertation : 
        Sujet: "${subject}"
        Problématique: "${plan.problematic}"
        Plan: ${JSON.stringify(plan.outline)}
        
        Identifie les faiblesses logiques, propose des contre-arguments forts (antithèse) que l'étudiant a oubliés, et donne des pistes d'amélioration concrètes.
        `,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              weaknesses: { type: Type.ARRAY, items: { type: Type.STRING } },
              counterArguments: { type: Type.ARRAY, items: { type: Type.STRING } },
              improvements: { type: Type.ARRAY, items: { type: Type.STRING } },
              gradeEstimate: { type: Type.STRING }
            },
            required: ["weaknesses", "counterArguments", "improvements", "gradeEstimate"]
          }
        }
      });
      if (response.text) {
        setCritique(JSON.parse(response.text));
      }
    } catch (e) {
      console.error(e);
      alert("Erreur lors de la génération de la critique.");
    } finally {
      setCritiqueLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="bg-amber-700 text-white p-10 rounded-2xl shadow-xl">
        <h2 className="text-3xl font-bold mb-4 serif">Architecte de Dissertation</h2>
        <p className="text-amber-100 mb-8 max-w-2xl">Entrez votre sujet ou votre question de recherche pour obtenir une structure académique solide (Plan en deux ou trois parties).</p>
        
        <div className="flex flex-col gap-6">
          <div className="flex flex-col md:flex-row gap-4">
            <input
              type="text"
              className="flex-1 p-4 bg-white text-slate-900 rounded-xl outline-none shadow-inner placeholder:text-slate-400"
              placeholder="Ex: La légitimité de l'État dans la mondialisation est-elle menacée ?"
              value={subject}
              onChange={(e) => setSubject(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && generatePlan()}
            />
            <button
              onClick={() => generatePlan()}
              disabled={loading}
              className="bg-slate-900 text-white px-8 py-4 rounded-xl font-bold hover:bg-black transition-all disabled:opacity-50 shadow-lg whitespace-nowrap"
            >
              {loading ? (
                <span className="flex items-center">
                  <svg className="animate-spin -ml-1 mr-2 h-4 w-4 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Construction...
                </span>
              ) : 'Bâtir le Plan'}
            </button>
          </div>

          <div>
            <p className="text-[10px] font-bold uppercase tracking-widest text-amber-200 mb-3">Sujets d'entraînement suggérés :</p>
            <div className="flex flex-wrap gap-2">
              {EXAMPLE_TOPICS.map((topic, index) => (
                <button
                  key={index}
                  onClick={() => generatePlan(topic)}
                  disabled={loading}
                  className="px-4 py-2 bg-amber-800/50 hover:bg-amber-600 border border-amber-600/30 rounded-lg text-xs font-medium text-amber-50 transition-colors text-left"
                >
                  {topic}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {plan && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 animate-fadeIn">
          <div className="lg:col-span-8 space-y-6">
            <div className="bg-white p-8 rounded-xl shadow-sm border border-slate-200">
              <h3 className="text-2xl font-bold mb-6 serif text-slate-800 border-b pb-4">{plan.title}</h3>
              
              <div className="mb-8 p-6 bg-amber-50 rounded-lg border-l-4 border-amber-500">
                <h4 className="font-bold text-amber-800 mb-2 uppercase text-xs tracking-widest">Problématique</h4>
                <p className="text-slate-700 italic font-medium">"{plan.problematic}"</p>
              </div>

              <div className="space-y-8">
                {plan.outline.map((p, i) => (
                  <div key={i} className="space-y-4">
                    <h4 className="text-xl font-bold text-slate-900 flex items-center">
                      <span className="bg-[#002147] text-white w-8 h-8 rounded-full inline-flex items-center justify-center mr-3 text-sm font-serif shadow-md">{['I', 'II', 'III'][i] || i + 1}</span>
                      {p.part}
                    </h4>
                    <div className="ml-4 pl-7 border-l-2 border-slate-100 space-y-3">
                      {p.subparts.map((sub, j) => (
                        <div key={j} className="text-slate-700 text-sm flex items-start group">
                          <span className="text-amber-500 mr-3 mt-1 text-xs opacity-50 group-hover:opacity-100 transition-opacity">●</span>
                          <span className="group-hover:text-[#002147] transition-colors">{sub}</span>
                        </div>
                      ))}
                    </div>
                  </div>
                ))}
              </div>

              <div className="mt-12 pt-8 border-t border-slate-100 bg-slate-50/50 -mx-8 px-8 pb-4">
                <h4 className="font-bold text-slate-400 mb-3 uppercase text-[10px] tracking-widest">Piste de Conclusion</h4>
                <p className="text-slate-600 text-sm leading-relaxed italic border-l-2 border-slate-300 pl-4">{plan.conclusion}</p>
              </div>
            </div>

            {/* SECTION CRITIQUE (AVOCAT DU DIABLE) */}
            {critique ? (
              <div className="bg-slate-50 border border-slate-200 p-8 rounded-xl animate-fadeIn relative overflow-hidden">
                <div className="absolute top-0 right-0 p-4 opacity-5 text-6xl">⚖️</div>
                <div className="flex justify-between items-center mb-6">
                   <h3 className="text-lg font-bold serif text-[#002147] flex items-center">
                     <span className="mr-2 text-xl">🧐</span> Rapport du Correcteur
                   </h3>
                   <span className="text-xs font-bold bg-white px-3 py-1 rounded-full border border-slate-200">
                     Potentiel: {critique.gradeEstimate}
                   </span>
                </div>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <div className="space-y-4">
                    <div className="bg-red-50 p-4 rounded-lg border border-red-100">
                      <h4 className="text-xs font-bold text-red-800 uppercase tracking-widest mb-2">Faiblesses Logiques</h4>
                      <ul className="list-disc list-inside space-y-1">
                        {critique.weaknesses.map((w, i) => (
                          <li key={i} className="text-xs text-red-900 leading-relaxed">{w}</li>
                        ))}
                      </ul>
                    </div>
                    <div className="bg-amber-50 p-4 rounded-lg border border-amber-100">
                      <h4 className="text-xs font-bold text-amber-800 uppercase tracking-widest mb-2">Oublis Majeurs (Antithèse)</h4>
                       <ul className="list-disc list-inside space-y-1">
                        {critique.counterArguments.map((w, i) => (
                          <li key={i} className="text-xs text-amber-900 leading-relaxed">{w}</li>
                        ))}
                      </ul>
                    </div>
                  </div>
                  
                  <div className="bg-emerald-50 p-4 rounded-lg border border-emerald-100 h-full">
                     <h4 className="text-xs font-bold text-emerald-800 uppercase tracking-widest mb-2">Pistes d'Amélioration</h4>
                     <ul className="space-y-3">
                        {critique.improvements.map((imp, i) => (
                          <li key={i} className="flex items-start text-xs text-emerald-900 leading-relaxed">
                            <span className="mr-2 font-bold">→</span> {imp}
                          </li>
                        ))}
                      </ul>
                  </div>
                </div>
              </div>
            ) : (
              <button 
                onClick={generateCritique}
                disabled={critiqueLoading}
                className="w-full py-4 bg-slate-100 hover:bg-slate-200 border-2 border-dashed border-slate-300 rounded-xl text-slate-500 font-bold uppercase text-xs tracking-widest transition-all hover:text-[#002147] hover:border-[#002147]"
              >
                {critiqueLoading ? "L'examinateur relit votre copie..." : "👨‍🏫 Demander une critique sévère du plan"}
              </button>
            )}
          </div>

          <div className="lg:col-span-4 space-y-6">
            <div className="bg-white p-6 rounded-xl border border-slate-200 sticky top-8 shadow-sm">
              <h4 className="font-bold text-slate-800 mb-4 serif uppercase text-sm border-b border-slate-100 pb-2">Conseils Méthodo</h4>
              <ul className="space-y-4 text-sm text-slate-600">
                <li className="flex gap-3 items-start">
                  <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                  <span>Soignez les <strong>transitions</strong> entre les parties pour assurer la fluidité du raisonnement.</span>
                </li>
                <li className="flex gap-3 items-start">
                  <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                  <span>Chaque sous-partie doit être illustrée par au moins un <strong>auteur de référence</strong> ou un fait historique précis.</span>
                </li>
                <li className="flex gap-3 items-start">
                  <span className="text-emerald-500 font-bold mt-0.5">✓</span>
                  <span>La problématique doit être une <strong>tension</strong> (paradoxe) et non une simple question de cours.</span>
                </li>
              </ul>
              <button className="w-full mt-6 py-3 border-2 border-[#002147] text-[#002147] rounded-lg font-bold hover:bg-[#002147] hover:text-white transition-all text-xs uppercase tracking-widest">
                Télécharger en PDF
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default EssayArchitect;
