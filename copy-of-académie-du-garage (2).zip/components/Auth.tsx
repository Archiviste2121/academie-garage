
import React, { useState, useRef, useEffect } from 'react';
import { UserProfile } from '../types';

interface AuthProps {
  onComplete: (profile: UserProfile) => void;
  existingProfile: UserProfile | null;
}

const Auth: React.FC<AuthProps> = ({ onComplete, existingProfile }) => {
  // Modes: 'register' (création), 'login' (import), 'unlock' (code pin)
  const [mode, setMode] = useState<'register' | 'login' | 'unlock'>('register');
  
  const [pseudonym, setPseudonym] = useState('');
  const [pin, setPin] = useState('');
  const [confirmPin, setConfirmPin] = useState('');
  const [unlockPin, setUnlockPin] = useState('');
  const [error, setError] = useState('');
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (existingProfile) {
      setMode('unlock');
    }
  }, [existingProfile]);

  const handleRegister = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!pseudonym.trim()) {
      setError("Le pseudonyme est requis.");
      return;
    }
    if (pin.length < 4) {
      setError("Le code PIN doit contenir au moins 4 chiffres.");
      return;
    }
    if (pin !== confirmPin) {
      setError("Les codes PIN ne correspondent pas.");
      return;
    }

    const profile: UserProfile = {
      pseudonym: pseudonym.trim(),
      avatarColor: 'bg-[#002147]',
      joinedDate: Date.now(),
      pin: pin
    };
    
    localStorage.setItem('agora_user_profile', JSON.stringify(profile));
    onComplete(profile);
  };

  const handleUnlock = (e: React.FormEvent) => {
    e.preventDefault();
    if (existingProfile && unlockPin === existingProfile.pin) {
      onComplete(existingProfile);
    } else {
      setError("Code PIN incorrect.");
      setUnlockPin('');
    }
  };

  const handleImport = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);
        const d = parsed.meta ? parsed.data : parsed;

        if (!d.profile) throw new Error("Fichier de sauvegarde invalide");

        // Restauration
        localStorage.setItem('agora_user_profile', d.profile);
        if (d.notes) localStorage.setItem('agora_user_notes', d.notes);
        if (d.journal) localStorage.setItem('agora_journal', d.journal);
        if (d.seminars) localStorage.setItem('agora_seminar_history', d.seminars);
        if (d.favorites) localStorage.setItem('agora_theory_favorites', d.favorites);
        if (d.driveUrl) localStorage.setItem('agora_drive_course_url', d.driveUrl);
        if (d.driveLinks) localStorage.setItem('agora_drive_custom_links', d.driveLinks);

        const profile = JSON.parse(d.profile);
        
        // Si le profil importé n'a pas de PIN (vieux fichier), on le force à en mettre un ? 
        // Pour l'instant, on assume qu'il se connecte directement, 
        // l'utilisateur devra aller dans son profil pour sécuriser si besoin.
        onComplete(profile);
      } catch (error) {
        alert("Erreur: Le fichier est corrompu ou illisible.");
        console.error(error);
      }
    };
    reader.readAsText(file);
  };

  const resetData = () => {
    if (confirm("Attention : Cela effacera toutes les données locales de ce navigateur. Êtes-vous sûr ?")) {
      localStorage.clear();
      window.location.reload();
    }
  };

  return (
    <div className="min-h-screen bg-[#f8fafc] flex flex-col items-center justify-center p-6 relative overflow-hidden">
      <div className="absolute inset-0 bg-[url('https://www.transparenttextures.com/patterns/pinstriped-suit.png')] opacity-5"></div>
      
      <div className="max-w-md w-full animate-fadeIn relative z-10">
        <div className="text-center mb-8 space-y-4">
          <div className="inline-block p-4 rounded-xl bg-white border border-slate-200 shadow-sm mb-4">
             <img 
              src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Flag_of_Quebec.svg" 
              alt="Québec" 
              className="w-20 h-auto shadow-sm border border-black/5" 
            />
          </div>
          <h1 className="text-3xl font-bold text-[#002147] serif tracking-tight">Académie du Garage</h1>
          <div className="w-12 h-0.5 bg-[#003399] mx-auto"></div>
          <p className="text-slate-500 text-xs uppercase font-bold tracking-[0.3em]">Coffre-fort Académique</p>
        </div>

        {/* Onglets seulement si pas en mode Unlock */}
        {mode !== 'unlock' && (
          <div className="bg-white p-2 rounded-xl border border-slate-200 shadow-sm flex mb-6">
            <button 
              onClick={() => setMode('register')}
              className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'register' ? 'bg-[#002147] text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
            >
              Créer
            </button>
            <button 
              onClick={() => setMode('login')}
              className={`flex-1 py-3 text-xs font-bold uppercase tracking-widest rounded-lg transition-all ${mode === 'login' ? 'bg-[#002147] text-white shadow-md' : 'text-slate-400 hover:bg-slate-50'}`}
            >
              Restaurer
            </button>
          </div>
        )}

        <div className="bg-white p-10 rounded-2xl border border-slate-200 shadow-2xl relative">
          
          {mode === 'unlock' && existingProfile && (
            <form onSubmit={handleUnlock} className="space-y-6 animate-fadeIn text-center">
              <div className="w-20 h-20 bg-[#002147] text-white rounded-2xl flex items-center justify-center text-3xl font-bold mx-auto shadow-lg mb-6">
                {existingProfile.pseudonym.charAt(0).toUpperCase()}
              </div>
              <div>
                <h2 className="text-xl font-bold text-slate-900">Bonjour, {existingProfile.pseudonym}</h2>
                <p className="text-slate-400 text-sm">Veuillez déverrouiller votre espace.</p>
              </div>

              <div className="space-y-2 text-left">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Code PIN</label>
                <input
                  type="password"
                  required
                  placeholder="••••"
                  maxLength={8}
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-4 text-center text-2xl tracking-[0.5em] font-bold text-slate-900 focus:ring-1 focus:ring-[#002147] outline-none transition-all"
                  value={unlockPin}
                  onChange={(e) => {
                    setUnlockPin(e.target.value);
                    setError('');
                  }}
                  autoFocus
                />
              </div>

              {error && <p className="text-red-500 text-xs font-bold bg-red-50 p-2 rounded animate-pulse">{error}</p>}

              <button
                type="submit"
                className="w-full bg-[#002147] hover:bg-black text-white font-bold py-4 rounded-lg transition-all shadow-lg active:scale-[0.98] text-xs uppercase tracking-widest"
              >
                Déverrouiller
              </button>
              
              <button 
                type="button"
                onClick={resetData}
                className="text-[10px] text-slate-300 hover:text-red-500 underline mt-4"
              >
                Mot de passe oublié ? Réinitialiser l'application
              </button>
            </form>
          )}

          {mode === 'register' && (
            <form onSubmit={handleRegister} className="space-y-6 animate-fadeIn">
              <div className="space-y-2">
                <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Identité</label>
                <input
                  type="text"
                  required
                  placeholder="Votre nom ou pseudonyme..."
                  className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-slate-900 focus:ring-1 focus:ring-[#002147] outline-none font-medium"
                  value={pseudonym}
                  onChange={(e) => setPseudonym(e.target.value)}
                />
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                   <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Créer PIN</label>
                   <input
                    type="password"
                    required
                    placeholder="••••"
                    maxLength={8}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-center font-bold tracking-widest focus:ring-1 focus:ring-[#002147] outline-none"
                    value={pin}
                    onChange={(e) => setPin(e.target.value)}
                  />
                </div>
                <div className="space-y-2">
                   <label className="text-[10px] font-bold text-slate-400 uppercase tracking-widest ml-1">Confirmer</label>
                   <input
                    type="password"
                    required
                    placeholder="••••"
                    maxLength={8}
                    className="w-full bg-slate-50 border border-slate-200 rounded-lg px-4 py-3 text-center font-bold tracking-widest focus:ring-1 focus:ring-[#002147] outline-none"
                    value={confirmPin}
                    onChange={(e) => setConfirmPin(e.target.value)}
                  />
                </div>
              </div>

              {error && <p className="text-red-500 text-xs font-bold">{error}</p>}

              <div className="flex items-start space-x-3 bg-blue-50 p-3 rounded-lg border border-blue-100">
                <div className="text-blue-500 mt-0.5">🔒</div>
                <p className="text-xs text-blue-900 leading-tight">
                  Ce code PIN sécurisera l'accès à vos notes sur cet appareil. Ne l'oubliez pas.
                </p>
              </div>

              <button
                type="submit"
                className="w-full bg-[#002147] hover:bg-black text-white font-bold py-4 rounded-lg transition-all shadow-lg active:scale-[0.98] text-xs uppercase tracking-widest"
              >
                Sécuriser et Entrer
              </button>
            </form>
          )}

          {mode === 'login' && (
            <div className="space-y-6 animate-fadeIn text-center">
              <div className="p-6 bg-slate-50 rounded-xl border border-slate-200 mb-4">
                <p className="text-sm text-slate-600 mb-4">
                  Importez votre fichier <strong className="text-[#002147] font-mono">Cartable_Numerique.json</strong> pour retrouver toutes vos notes et travaux.
                </p>
                <input
                  type="file"
                  accept=".json"
                  ref={fileInputRef}
                  className="hidden"
                  onChange={handleImport}
                />
                <button
                  type="button"
                  onClick={() => fileInputRef.current?.click()}
                  className="w-full bg-[#003399] text-white font-bold py-4 rounded-lg transition-all hover:bg-[#002147] shadow-lg flex items-center justify-center space-x-2"
                >
                  <span>📂 Choisir le fichier</span>
                </button>
              </div>
            </div>
          )}
        </div>
      </div>
      
      <footer className="mt-12 text-[9px] text-slate-400 font-bold uppercase tracking-widest z-10">
        © Académie du Garage - Département de Théorie Politique
      </footer>
    </div>
  );
};

export default Auth;
