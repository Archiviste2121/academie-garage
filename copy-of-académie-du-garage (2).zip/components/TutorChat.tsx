
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Chat, GenerateContentResponse } from "@google/genai";
import { ChatMessage } from '../types';

const TutorChat: React.FC = () => {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const chatSessionRef = useRef<Chat | null>(null);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const aiRef = useRef<GoogleGenAI | null>(null);

  // Charger l'historique au montage
  useEffect(() => {
    const saved = localStorage.getItem('agora_tutor_history');
    if (saved) {
      try {
        const history = JSON.parse(saved);
        setMessages(history);
      } catch (e) {
        console.error("Erreur de lecture de l'historique chat", e);
      }
    } else {
      // Message de bienvenue par défaut si pas d'historique
      setMessages([{
        id: 'welcome',
        role: 'model',
        text: "Bonjour ! Je suis ton tuteur en science politique. Une question sur un concept, un auteur ou besoin d'une clarification sur l'actualité ?",
        timestamp: Date.now()
      }]);
    }

    aiRef.current = new GoogleGenAI({ apiKey: process.env.API_KEY });
  }, []);

  // Re-créer la session de chat quand les messages changent (pour garder le contexte)
  // Note: Dans une app complexe, on optimiserait pour ne pas recréer à chaque fois, 
  // mais ici on assure que le contexte est synchronisé si on recharge la page.
  useEffect(() => {
    if (aiRef.current && messages.length > 0) {
      const historyForModel = messages
        .filter(m => m.id !== 'welcome') // On ne passe pas le message de bienvenue hardcodé comme historique au modèle s'il n'est pas nécessaire
        .map(m => ({
          role: m.role,
          parts: [{ text: m.text }]
        }));

      chatSessionRef.current = aiRef.current.chats.create({
        model: 'gemini-3-flash-preview',
        history: historyForModel,
        config: {
          systemInstruction: `Tu es un tuteur pédagogique universitaire expert en Science Politique. 
          Ton rôle est d'aider un étudiant à comprendre ses cours, à clarifier des concepts et à réviser.
          Tes réponses doivent être :
          1. Pédagogiques et claires.
          2. Rigoureuses académiquement (cite des auteurs si pertinent).
          3. Concises (évite les longs pavés, préfère les listes ou paragraphes courts).
          4. Encourageantes.
          Réponds toujours en Français.`,
        },
      });
      
      // Sauvegarde automatique
      localStorage.setItem('agora_tutor_history', JSON.stringify(messages));
    }
  }, [messages]);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, loading]);

  const handleSend = async () => {
    if (!input.trim() || !aiRef.current) return;

    // Si pas de session (ex: premier message après clear), on initialise
    if (!chatSessionRef.current) {
        chatSessionRef.current = aiRef.current.chats.create({
            model: 'gemini-3-flash-preview',
            config: {
                systemInstruction: `Tu es un tuteur pédagogique universitaire expert en Science Politique.`,
            },
        });
    }

    const userMsg: ChatMessage = {
      id: Date.now().toString(),
      role: 'user',
      text: input,
      timestamp: Date.now()
    };

    setMessages(prev => [...prev, userMsg]);
    setInput('');
    setLoading(true);

    try {
      const response = await chatSessionRef.current.sendMessageStream({ message: userMsg.text });
      
      const modelMsgId = (Date.now() + 1).toString();
      let fullText = '';
      
      // Placeholder pour le message du modèle
      setMessages(prev => [...prev, {
        id: modelMsgId,
        role: 'model',
        text: '',
        timestamp: Date.now()
      }]);

      for await (const chunk of response) {
        const c = chunk as GenerateContentResponse;
        if (c.text) {
          fullText += c.text;
          setMessages(prev => prev.map(msg => 
            msg.id === modelMsgId ? { ...msg, text: fullText } : msg
          ));
        }
      }
    } catch (error) {
      console.error("Erreur Chat:", error);
      setMessages(prev => [...prev, {
        id: Date.now().toString(),
        role: 'model',
        text: "Désolé, j'ai rencontré une erreur de connexion. Veuillez réessayer.",
        timestamp: Date.now()
      }]);
    } finally {
      setLoading(false);
    }
  };

  const clearHistory = () => {
    if(confirm("Effacer tout l'historique de conversation ?")) {
        setMessages([{
            id: 'welcome',
            role: 'model',
            text: "Historique effacé. De quoi veux-tu parler ?",
            timestamp: Date.now()
        }]);
        localStorage.removeItem('agora_tutor_history');
        chatSessionRef.current = null;
    }
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-7rem)] lg:h-[calc(100vh-8rem)] bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden animate-fadeIn">
      {/* Header */}
      <div className="bg-[#002147] p-4 flex items-center justify-between text-white shrink-0">
        <div className="flex items-center space-x-3">
          <div className="w-10 h-10 bg-white/10 rounded-full flex items-center justify-center text-xl backdrop-blur-sm">
            🤖
          </div>
          <div>
            <h2 className="font-bold serif">Tuteur Intelligent</h2>
            <p className="text-[10px] text-blue-200 uppercase tracking-widest">Assistant Pédagogique 24/7</p>
          </div>
        </div>
        <button 
          onClick={clearHistory} 
          className="text-xs text-blue-300 hover:text-white transition-colors uppercase font-bold tracking-wider px-3 py-1 rounded hover:bg-white/10"
        >
          Nouvelle Discussion
        </button>
      </div>

      {/* Messages Area */}
      <div className="flex-1 overflow-y-auto p-4 md:p-6 space-y-6 bg-slate-50 scroll-smooth">
        {messages.map((msg) => (
          <div 
            key={msg.id} 
            className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div 
              className={`max-w-[85%] md:max-w-[70%] p-4 rounded-2xl shadow-sm text-sm leading-relaxed whitespace-pre-wrap ${
                msg.role === 'user' 
                ? 'bg-[#003399] text-white rounded-br-none' 
                : 'bg-white text-slate-800 border border-slate-200 rounded-bl-none'
              }`}
            >
              {msg.text}
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white p-4 rounded-2xl rounded-bl-none border border-slate-200 shadow-sm flex space-x-1">
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce"></div>
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-100"></div>
              <div className="w-2 h-2 bg-slate-400 rounded-full animate-bounce delay-200"></div>
            </div>
          </div>
        )}
        <div ref={messagesEndRef} />
      </div>

      {/* Input Area */}
      <div className="p-3 md:p-4 bg-white border-t border-slate-200 shrink-0">
        <div className="flex gap-2 md:gap-4">
          <textarea
            value={input}
            onChange={(e) => setInput(e.target.value)}
            onKeyDown={(e) => {
              if (e.key === 'Enter' && !e.shiftKey) {
                e.preventDefault();
                handleSend();
              }
            }}
            placeholder="Posez votre question..."
            className="flex-1 bg-slate-50 border border-slate-200 rounded-xl p-3 focus:ring-2 focus:ring-[#002147] outline-none resize-none h-[50px] md:h-[60px] text-sm"
          />
          <button
            onClick={handleSend}
            disabled={loading || !input.trim()}
            className="bg-[#002147] text-white px-4 md:px-6 rounded-xl font-bold hover:bg-black transition-colors disabled:opacity-50 shadow-md text-sm"
          >
            Envoyer
          </button>
        </div>
      </div>
    </div>
  );
};

export default TutorChat;
