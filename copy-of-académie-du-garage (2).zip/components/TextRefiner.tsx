
import React, { useState } from 'react';
import { GoogleGenAI, Type } from "@google/genai";

type RefinementMode = 'correction' | 'humanize' | 'academic';

const TextRefiner: React.FC = () => {
  const [inputText, setInputText] = useState('');
  const [outputText, setOutputText] = useState('');
  const [editorNote, setEditorNote] = useState('');
  const [mode, setMode] = useState<RefinementMode>('humanize');
  const [loading, setLoading] = useState(false);

  const handleRefine = async () => {
    if (!inputText.trim()) return;
    setLoading(true);
    setEditorNote('');
    setOutputText('');

    let prompt = "";
    if (mode === 'correction') {
      prompt = `Agis comme un correcteur professionnel. Corrige strictement les fautes d'orthographe, de grammaire et de syntaxe du texte suivant. Ne change pas le style.`;
    } else if (mode === 'humanize') {
      prompt = `Agis comme un écrivain talentueux. Réécris le texte suivant pour le rendre plus naturel, fluide et humain. Élimine les tournures robotiques ou répétitives. Garde le sens original mais améliore la lisibilité.`;
    } else if (mode === 'academic') {
      prompt = `Agis comme un professeur d'université en science politique. Reformule le texte suivant pour adopter un ton académique, formel et rigoureux. Utilise un vocabulaire précis (science po, sociologie).`;
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `${prompt}
        
        Texte à traiter : "${inputText}"
        
        Réponds uniquement au format JSON avec deux champs : "refinedText" (le texte corrigé/amélioré) et "editorNote" (une courte explication des changements majeurs ou un conseil).`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              refinedText: { type: Type.STRING },
              editorNote: { type: Type.STRING }
            },
            required: ["refinedText", "editorNote"]
          }
        }
      });

      const result = JSON.parse(response.text || "{}");
      setOutputText(result.refinedText || "Erreur de traitement.");
      setEditorNote(result.editorNote || "");
    } catch (error) {
      console.error(error);
      alert("Erreur lors de la correction.");
    } finally {
      setLoading(false);
    }
  };

  const copyToClipboard = () => {
    navigator.clipboard.writeText(outputText);
    alert("Texte copié !");
  };

  return (
    <div className="space-y-4 md:space-y-8 animate-fadeIn h-[calc(100dvh-7rem)] lg:h-[calc(100vh-8rem)] flex flex-col">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4 shrink-0">
        <div>
          <h2 className="text-2xl md:text-3xl font-bold serif text-slate-900">Atelier de Rédaction</h2>
          <p className="text-slate-500 text-sm hidden md:block">Correction grammaticale et amélioration stylistique assistée par IA.</p>
        </div>
        
        <div className="flex w-full md:w-auto bg-white p-1 rounded-xl border border-slate-200 shadow-sm overflow-x-auto">
          <button
            onClick={() => setMode('correction')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${mode === 'correction' ? 'bg-[#002147] text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            Correction
          </button>
          <button
            onClick={() => setMode('humanize')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${mode === 'humanize' ? 'bg-emerald-600 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            Humaniser
          </button>
          <button
            onClick={() => setMode('academic')}
            className={`flex-1 md:flex-none px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest transition-all ${mode === 'academic' ? 'bg-amber-700 text-white shadow-md' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            Académique
          </button>
        </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-4 md:gap-6 min-h-0">
        {/* Input Area */}
        <div className="flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
          <div className="p-3 md:p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center shrink-0">
            <span className="text-[10px] font-bold uppercase tracking-widest text-slate-400">Texte Original</span>
            {inputText && (
              <button onClick={() => setInputText('')} className="text-xs text-slate-400 hover:text-red-500 font-medium">Effacer</button>
            )}
          </div>
          <textarea
            className="flex-1 p-4 md:p-6 resize-none outline-none text-slate-700 leading-relaxed text-base md:text-lg"
            placeholder="Collez votre texte ici..."
            value={inputText}
            onChange={(e) => setInputText(e.target.value)}
          />
          <div className="p-3 md:p-4 bg-slate-50 border-t border-slate-200 text-right shrink-0">
             <button
              onClick={handleRefine}
              disabled={loading || !inputText}
              className={`w-full md:w-auto px-6 py-3 rounded-xl font-bold text-white transition-all shadow-md text-sm ${
                loading ? 'bg-slate-400 cursor-not-allowed' : 'bg-[#003399] hover:bg-[#002147] hover:-translate-y-0.5'
              }`}
            >
              {loading ? 'Analyse...' : 'Traiter le texte ✨'}
            </button>
          </div>
        </div>

        {/* Output Area - Hidden on mobile if empty unless we want to show results */}
        <div className={`flex flex-col bg-slate-50 rounded-2xl border border-slate-200 shadow-inner overflow-hidden relative ${!outputText && !loading ? 'hidden lg:flex' : 'flex'}`}>
          <div className="p-3 md:p-4 bg-white border-b border-slate-200 flex justify-between items-center shrink-0">
            <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600">
              Résultat
            </span>
            {outputText && (
              <button onClick={copyToClipboard} className="text-xs font-bold text-[#002147] hover:underline flex items-center">
                Copier
                <svg className="w-3 h-3 ml-1" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" /></svg>
              </button>
            )}
          </div>
          
          <div className="flex-1 p-4 md:p-6 overflow-y-auto">
            {loading ? (
              <div className="h-full flex flex-col items-center justify-center text-slate-400 space-y-4">
                <div className="w-8 h-8 border-2 border-[#002147] border-t-transparent rounded-full animate-spin"></div>
                <p className="text-xs font-medium animate-pulse">Réécriture intelligente...</p>
              </div>
            ) : outputText ? (
              <div className="space-y-6">
                <p className="text-slate-800 leading-relaxed text-base md:text-lg font-medium whitespace-pre-wrap animate-fadeIn">
                  {outputText}
                </p>
                {editorNote && (
                  <div className="mt-6 p-4 bg-amber-50 border border-amber-100 rounded-xl text-sm text-amber-900 animate-fadeIn">
                    <span className="font-bold text-amber-700 block text-xs uppercase mb-1">Note de l'éditeur IA :</span>
                    {editorNote}
                  </div>
                )}
              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-slate-300">
                <span className="text-4xl mb-2">🖋️</span>
                <p className="text-sm">Le résultat apparaîtra ici.</p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default TextRefiner;
