
import React, { useState, useEffect, useRef } from 'react';
import { GoogleGenAI, Modality, LiveServerMessage } from '@google/genai';
import { PastSeminarSession, SeminarTurn, UserNote } from '../types';

// Implémentation manuelle des fonctions d'encodage/décodage selon les guidelines
function decode(base64: string) {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

function encode(bytes: Uint8Array) {
  let binary = '';
  const len = bytes.byteLength;
  for (let i = 0; i < len; i++) {
    binary += String.fromCharCode(bytes[i]);
  }
  return btoa(binary);
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const LiveSeminar: React.FC = () => {
  const [isActive, setIsActive] = useState(false);
  const [showHistory, setShowHistory] = useState(false);
  const [pastSessions, setPastSessions] = useState<PastSeminarSession[]>([]);
  const [currentSessionTranscript, setCurrentSessionTranscript] = useState<SeminarTurn[]>([]);
  const [lastSavedId, setLastSavedId] = useState<string | null>(null);
  
  const nextStartTimeRef = useRef(0);
  const audioContextRef = useRef<AudioContext | null>(null);
  const sessionRef = useRef<any>(null);
  const sourcesRef = useRef<Set<AudioBufferSourceNode>>(new Set());
  
  const currentInputText = useRef('');
  const currentOutputText = useRef('');

  useEffect(() => {
    const saved = localStorage.getItem('agora_seminar_history');
    if (saved) {
      try {
        setPastSessions(JSON.parse(saved));
      } catch (e) {
        console.error("Erreur lors du chargement de l'historique", e);
      }
    }
  }, []);

  const saveCurrentSession = (transcript: SeminarTurn[]) => {
    if (transcript.length === 0) return;
    
    const newSession: PastSeminarSession = {
      id: Date.now().toString(),
      date: new Date().toLocaleString('fr-FR'),
      transcript: [...transcript]
    };
    
    const updatedHistory = [newSession, ...pastSessions];
    setPastSessions(updatedHistory);
    localStorage.setItem('agora_seminar_history', JSON.stringify(updatedHistory));
    setLastSavedId(newSession.id);
    
    // Notification temporaire
    setTimeout(() => setLastSavedId(null), 3000);
  };

  const copyToNotes = (session: PastSeminarSession) => {
    const savedNotes = localStorage.getItem('agora_user_notes');
    const notes: UserNote[] = savedNotes ? JSON.parse(savedNotes) : [];
    
    const content = session.transcript.map(t => 
      `${t.role === 'user' ? 'Étudiant' : 'Professeur'}: ${t.text}`
    ).join('\n\n');

    const newNote: UserNote = {
      id: Date.now().toString(),
      title: `Récap Séminaire - ${session.date}`,
      content: content,
      lastModified: Date.now()
    };

    localStorage.setItem('agora_user_notes', JSON.stringify([newNote, ...notes]));
    alert("Transcription copiée dans 'Mes Notes' !");
  };

  const downloadTranscript = (session: PastSeminarSession) => {
    const text = session.transcript.map(t => 
      `[${t.role.toUpperCase()}] ${t.text}`
    ).join('\n\n');
    
    const blob = new Blob([text], { type: 'text/plain' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `seminaire_${session.id}.txt`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const toggleSession = async () => {
    if (isActive) {
      setIsActive(false);
      sessionRef.current?.close();
      
      // On utilise le transcript actuel avant de le vider
      if (currentSessionTranscript.length > 0) {
        saveCurrentSession(currentSessionTranscript);
      }
      return;
    }

    try {
      setCurrentSessionTranscript([]);
      currentInputText.current = '';
      currentOutputText.current = '';
      
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const inputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 16000 });
      const outputCtx = new (window.AudioContext || (window as any).webkitAudioContext)({ sampleRate: 24000 });
      
      const outputGain = outputCtx.createGain();
      const compressor = outputCtx.createDynamicsCompressor();
      compressor.threshold.setValueAtTime(-24, outputCtx.currentTime);
      compressor.knee.setValueAtTime(40, outputCtx.currentTime);
      compressor.ratio.setValueAtTime(12, outputCtx.currentTime);
      compressor.attack.setValueAtTime(0, outputCtx.currentTime);
      compressor.release.setValueAtTime(0.25, outputCtx.currentTime);
      
      outputGain.connect(compressor);
      compressor.connect(outputCtx.destination);
      audioContextRef.current = outputCtx;

      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });

      const sessionPromise = ai.live.connect({
        model: 'gemini-2.5-flash-native-audio-preview-12-2025',
        callbacks: {
          onopen: () => {
            const source = inputCtx.createMediaStreamSource(stream);
            const scriptProcessor = inputCtx.createScriptProcessor(2048, 1, 1);
            
            scriptProcessor.onaudioprocess = (e) => {
              const inputData = e.inputBuffer.getChannelData(0);
              const l = inputData.length;
              const int16 = new Int16Array(l);
              for (let i = 0; i < l; i++) {
                const s = Math.max(-1, Math.min(1, inputData[i]));
                int16[i] = s < 0 ? s * 32768 : s * 32767;
              }
              const pcmBlob = {
                data: encode(new Uint8Array(int16.buffer)),
                mimeType: 'audio/pcm;rate=16000',
              };
              sessionPromise.then(session => {
                session.sendRealtimeInput({ media: pcmBlob });
              });
            };
            source.connect(scriptProcessor);
            scriptProcessor.connect(inputCtx.destination);
            setIsActive(true);
          },
          onmessage: async (message: LiveServerMessage) => {
            const base64Audio = message.serverContent?.modelTurn?.parts[0]?.inlineData?.data;
            if (base64Audio) {
              const ctx = audioContextRef.current!;
              nextStartTimeRef.current = Math.max(nextStartTimeRef.current, ctx.currentTime);
              const audioBuffer = await decodeAudioData(decode(base64Audio), ctx, 24000, 1);
              const source = ctx.createBufferSource();
              source.buffer = audioBuffer;
              source.connect(compressor);
              source.start(nextStartTimeRef.current);
              nextStartTimeRef.current += audioBuffer.duration;
              sourcesRef.current.add(source);
              source.onended = () => sourcesRef.current.delete(source);
            }

            if (message.serverContent?.inputTranscription) {
              currentInputText.current += message.serverContent.inputTranscription.text;
            }
            if (message.serverContent?.outputTranscription) {
              currentOutputText.current += message.serverContent.outputTranscription.text;
            }

            if (message.serverContent?.turnComplete) {
              const uText = currentInputText.current.trim();
              const mText = currentOutputText.current.trim();
              if (uText || mText) {
                setCurrentSessionTranscript(prev => [
                  ...prev, 
                  { role: 'user', text: uText || "..." }, 
                  { role: 'model', text: mText || "..." }
                ]);
              }
              currentInputText.current = '';
              currentOutputText.current = '';
            }

            if (message.serverContent?.interrupted) {
              sourcesRef.current.forEach(s => { try { s.stop(); } catch(e) {} });
              sourcesRef.current.clear();
              nextStartTimeRef.current = 0;
            }
          },
          onerror: () => setIsActive(false),
          onclose: () => setIsActive(false),
        },
        config: {
          responseModalities: [Modality.AUDIO],
          outputAudioTranscription: {},
          inputAudioTranscription: {},
          speechConfig: { voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } } },
          systemInstruction: "Tu es un professeur de sciences politiques expert en relations internationales à l'Académie du Garage. Tu es là pour un séminaire oral interactif. Ta voix doit être posée, académique et encourageante. Parle exclusivement en Français.",
        }
      });

      sessionRef.current = await sessionPromise;
    } catch (err) {
      console.error(err);
    }
  };

  const deleteSession = (id: string) => {
    if (confirm('Supprimer définitivement cette archive ?')) {
      const updated = pastSessions.filter(s => s.id !== id);
      setPastSessions(updated);
      localStorage.setItem('agora_seminar_history', JSON.stringify(updated));
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      <div className="flex justify-between items-end mb-4">
        <div>
          <h2 className="text-3xl font-bold serif text-slate-900">Séminaire Interactif</h2>
          <p className="text-slate-500 text-sm mt-1">Échangez de vive voix avec l'intelligence académique.</p>
        </div>
        <button 
          onClick={() => setShowHistory(!showHistory)}
          className={`flex items-center space-x-2 px-6 py-2 rounded-full font-bold transition-all border ${
            showHistory 
            ? 'bg-rose-50 text-rose-700 border-rose-200 shadow-inner' 
            : 'bg-white text-slate-700 border-slate-200 hover:border-rose-300 shadow-sm'
          }`}
        >
          <span>{showHistory ? "⬅️ Retour au Direct" : "📜 Voir les Archives"}</span>
        </button>
      </div>

      {!showHistory ? (
        <>
          <div className="bg-rose-950 text-white p-12 rounded-[2.5rem] shadow-2xl flex flex-col items-center text-center relative overflow-hidden group">
            <div className="absolute inset-0 bg-[radial-gradient(circle_at_top_right,_var(--tw-gradient-stops))] from-rose-500/20 via-transparent to-transparent"></div>
            
            <div className={`w-32 h-32 rounded-3xl flex items-center justify-center text-5xl mb-8 shadow-2xl transition-all duration-700 relative z-10 ${isActive ? 'bg-rose-500 animate-pulse scale-110 rotate-3' : 'bg-slate-800'}`}>
              {isActive ? (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" /></svg>
              ) : (
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-16 h-16"><path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.499 5.221 69.154 69.154 0 01-1.929.877m-18.029-.206a48.427 48.427 0 016.414-2.584c3.356-1.066 6.975-1.066 10.33 0 2.238.71 4.39 1.584 6.415 2.584m.002.005C21.418 11.232 20 13.974 20 17.069C20 19.533 18.23 21.6 15.823 22.044A48.672 48.672 0 0112 22.25c-2.31 0-4.577-.18-6.768-.523C2.825 21.36 1.25 19.22 1.25 16.897c0-2.903 1.257-5.516 3.255-7.397L4.26 10.147z" /></svg>
              )}
              {isActive && <div className="absolute inset-0 rounded-3xl animate-ping bg-rose-500/50"></div>}
            </div>
            
            <h2 className="text-4xl font-bold mb-4 serif relative z-10">Le Grand Oral</h2>
            <p className="text-rose-200 mb-10 max-w-xl text-lg font-medium relative z-10 opacity-80">Révisez vos concepts de sciences politiques par la parole. La transcription est sauvegardée automatiquement.</p>
            
            <div className="flex flex-col items-center space-y-4 relative z-10">
              <button
                onClick={toggleSession}
                className={`px-16 py-5 rounded-2xl font-black text-xl transition-all shadow-xl hover:-translate-y-1 active:scale-95 ${isActive ? 'bg-white text-rose-950' : 'bg-rose-500 text-white hover:bg-rose-400'}`}
              >
                {isActive ? 'Terminer & Archiver' : 'Lancer le Séminaire'}
              </button>
              
              {lastSavedId && (
                <div className="bg-emerald-500/20 text-emerald-400 border border-emerald-500/30 px-4 py-1.5 rounded-full text-xs font-bold animate-bounce mt-4">
                  ✓ Session archivée avec succès
                </div>
              )}
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mt-12">
            <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm overflow-hidden flex flex-col h-[500px]">
              <div className="flex justify-between items-center mb-6">
                <h3 className="text-xl font-bold serif text-slate-800">Transcription Live</h3>
                {isActive && <span className="flex h-2 w-2 rounded-full bg-rose-500 animate-ping"></span>}
              </div>
              <div className="flex-1 overflow-y-auto space-y-6 pr-4 text-sm scroll-smooth">
                {currentSessionTranscript.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-full text-slate-300 opacity-50 space-y-4">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={0.5} stroke="currentColor" className="w-24 h-24"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" /></svg>
                    <p className="italic font-medium">L'échange textuel apparaîtra ici...</p>
                  </div>
                ) : (
                  currentSessionTranscript.map((turn, i) => (
                    <div key={i} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                      <div className={`max-w-[85%] p-4 rounded-2xl shadow-sm ${turn.role === 'user' ? 'bg-rose-50 text-rose-900 border border-rose-100' : 'bg-slate-50 text-slate-800 border border-slate-200'}`}>
                        <div className="flex items-center space-x-2 mb-2">
                          <span className="text-[10px] uppercase font-black tracking-widest opacity-40">{turn.role === 'user' ? 'Étudiant' : 'Professeur'}</span>
                        </div>
                        <p className="leading-relaxed font-medium">{turn.text}</p>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>

            <div className="space-y-6">
              <div className="bg-white p-8 rounded-[2rem] border border-slate-100 shadow-sm">
                <h3 className="text-xl font-bold mb-6 serif text-slate-800">Axes de Réflexion</h3>
                <div className="space-y-4">
                  {[
                    { t: "Théories du Pouvoir", d: "Interrogez Foucault sur la micro-physique du pouvoir." },
                    { t: "Géopolitique de l'IA", d: "Discutez de la souveraineté numérique." },
                    { t: "Droit International", d: "Le rôle de l'ONU face aux nouveaux conflits." }
                  ].map((item, i) => (
                    <div key={i} className="p-5 bg-slate-50 rounded-2xl text-sm border-l-4 border-rose-500 hover:bg-rose-50 transition-all cursor-pointer group">
                      <p className="font-black text-slate-900 group-hover:text-rose-700 transition-colors">{item.t}</p>
                      <p className="text-slate-500 mt-1">{item.d}</p>
                    </div>
                  ))}
                </div>
              </div>
              <div className="bg-amber-900/5 p-8 rounded-[2rem] border border-amber-100 text-amber-900">
                <p className="text-sm font-medium italic">"Chaque parole est un pas de plus vers la maîtrise du concept. Osez formuler vos hypothèses."</p>
              </div>
            </div>
          </div>
        </>
      ) : (
        <div className="space-y-8 animate-fadeIn">
          <header className="bg-white p-10 rounded-[2.5rem] border border-slate-100 shadow-sm">
            <h3 className="text-3xl font-bold serif text-slate-900">Vos Archives Académiques</h3>
            <p className="text-slate-500 font-medium mt-2">Retrouvez et analysez vos sessions passées.</p>
          </header>

          {pastSessions.length === 0 ? (
            <div className="bg-white p-20 rounded-[2.5rem] border border-dashed border-slate-200 text-center">
              <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={0.5} stroke="currentColor" className="w-24 h-24 mx-auto mb-6 text-slate-300"><path strokeLinecap="round" strokeLinejoin="round" d="M20.25 7.5l-.625 10.632a2.25 2.25 0 01-2.247 2.118H6.622a2.25 2.25 0 01-2.247-2.118L3.75 7.5m8.25 3v6.75m0 0l-3-3m3 3l3-3M3.375 7.5h17.25c.621 0 1.125-.504 1.125-1.125v-1.5c0-.621-.504-1.125-1.125-1.125H3.375c-.621 0-1.125.504-1.125 1.125v1.5c0 .621.504 1.125 1.125 1.125z" /></svg>
              <p className="text-slate-400 font-bold text-xl serif">Aucun séminaire enregistré pour le moment.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 gap-8">
              {pastSessions.map((session) => (
                <div key={session.id} className="bg-white rounded-[2.5rem] border border-slate-100 shadow-sm overflow-hidden group hover:shadow-xl transition-all duration-500">
                  <div className="p-8 bg-slate-50/50 border-b border-slate-100 flex flex-wrap justify-between items-center gap-4">
                    <div className="flex items-center space-x-4">
                      <div className="bg-rose-100 text-rose-700 w-12 h-12 rounded-2xl flex items-center justify-center text-xl">
                          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.499 5.221 69.154 69.154 0 01-1.929.877m-18.029-.206a48.427 48.427 0 016.414-2.584c3.356-1.066 6.975-1.066 10.33 0 2.238.71 4.39 1.584 6.415 2.584m.002.005C21.418 11.232 20 13.974 20 17.069C20 19.533 18.23 21.6 15.823 22.044A48.672 48.672 0 0112 22.25c-2.31 0-4.577-.18-6.768-.523C2.825 21.36 1.25 19.22 1.25 16.897c0-2.903 1.257-5.516 3.255-7.397L4.26 10.147z" /></svg>
                      </div>
                      <div>
                        <span className="block font-black text-slate-900 text-lg">Session du {session.date}</span>
                        <span className="text-[10px] uppercase font-black tracking-widest text-slate-400">
                          {session.transcript.length / 2} Échanges terminés
                        </span>
                      </div>
                    </div>
                    <div className="flex items-center space-x-3">
                      <button 
                        onClick={() => copyToNotes(session)}
                        className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-rose-50 hover:text-rose-700 hover:border-rose-200 transition-all shadow-sm"
                      >
                        📝 Copier vers Notes
                      </button>
                      <button 
                        onClick={() => downloadTranscript(session)}
                        className="bg-white border border-slate-200 px-4 py-2 rounded-xl text-xs font-black uppercase tracking-widest text-slate-600 hover:bg-slate-900 hover:text-white transition-all shadow-sm"
                      >
                        💾 Télécharger (.txt)
                      </button>
                      <button 
                        onClick={() => deleteSession(session.id)}
                        className="p-2 text-slate-300 hover:text-red-500 transition-colors"
                        title="Supprimer l'archive"
                      >
                        <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                      </button>
                    </div>
                  </div>
                  <div className="p-10 max-h-[500px] overflow-y-auto space-y-8 bg-[url('https://www.transparenttextures.com/patterns/lined-paper.png')] bg-fixed">
                    {session.transcript.map((turn, idx) => (
                      <div key={idx} className={`flex ${turn.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                        <div className={`max-w-[85%] p-6 rounded-3xl text-sm leading-relaxed ${turn.role === 'user' ? 'bg-rose-50 text-rose-900 shadow-sm border border-rose-100/50' : 'bg-white text-slate-800 border border-slate-100 shadow-sm'}`}>
                          <div className="flex items-center space-x-2 mb-3">
                            <span className="text-[10px] uppercase font-black tracking-[0.2em] opacity-30">{turn.role === 'user' ? 'Étudiant' : 'Professeur'}</span>
                          </div>
                          <p className="font-medium text-base">{turn.text}</p>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      )}
    </div>
  );
};

export default LiveSeminar;
