
import React, { useState, useEffect, useRef } from 'react';
import { UserProfile } from '../types';

interface AccountProfileProps {
  user: UserProfile;
  onUpdateUser: (user: UserProfile) => void;
  onLogout: () => void;
}

interface BackupStats {
  notesCount: number;
  journalCount: number;
  seminarCount: number;
  favoritesCount: number;
  driveLinksCount: number;
  date: string;
}

const AccountProfile: React.FC<AccountProfileProps> = ({ user, onUpdateUser, onLogout }) => {
  const [stats, setStats] = useState({
    notes: 0,
    journalEntries: 0,
    seminars: 0,
    favorites: 0
  });
  const [isEditing, setIsEditing] = useState(false);
  const [editName, setEditName] = useState(user.pseudonym);
  const [lastBackupDate, setLastBackupDate] = useState<string | null>(null);
  const [importPreview, setImportPreview] = useState<BackupStats | null>(null);
  const [pendingImportData, setPendingImportData] = useState<any | null>(null);
  
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    // Calcul des statistiques
    const notes = JSON.parse(localStorage.getItem('agora_user_notes') || '[]');
    const journal = JSON.parse(localStorage.getItem('agora_journal') || '[]');
    const seminars = JSON.parse(localStorage.getItem('agora_seminar_history') || '[]');
    const favs = JSON.parse(localStorage.getItem('agora_theory_favorites') || '[]');
    const lastBackup = localStorage.getItem('agora_last_backup_date');

    setStats({
      notes: notes.length,
      journalEntries: journal.length,
      seminars: seminars.length,
      favorites: favs.length
    });

    if (lastBackup) {
      setLastBackupDate(new Date(parseInt(lastBackup)).toLocaleString('fr-FR'));
    }
  }, []);

  const handleSaveProfile = () => {
    const updatedUser = { ...user, pseudonym: editName };
    localStorage.setItem('agora_user_profile', JSON.stringify(updatedUser));
    onUpdateUser(updatedUser);
    setIsEditing(false);
  };

  const handleExport = () => {
    try {
      const now = Date.now();
      const data = {
        meta: {
          version: "2.0",
          exportedAt: now,
          app: "AcademieDuGarage"
        },
        data: {
          profile: localStorage.getItem('agora_user_profile'),
          notes: localStorage.getItem('agora_user_notes'),
          journal: localStorage.getItem('agora_journal'),
          seminars: localStorage.getItem('agora_seminar_history'),
          favorites: localStorage.getItem('agora_theory_favorites'),
          driveUrl: localStorage.getItem('agora_drive_course_url'),
          driveLinks: localStorage.getItem('agora_drive_custom_links')
        }
      };

      const blob = new Blob([JSON.stringify(data, null, 2)], { type: 'application/json' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      // Nom de fichier sécurisé
      const safeName = user.pseudonym.replace(/[^a-z0-9]/gi, '_').toLowerCase();
      a.download = `Cartable_Numerique_${safeName}_${new Date().toISOString().split('T')[0]}.json`;
      
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);

      // CRITIQUE : Délai nécessaire pour que le navigateur initie le téléchargement avant de détruire le lien
      // C'est ce qui causait l'erreur ERR_FILE_NOT_FOUND
      setTimeout(() => {
        URL.revokeObjectURL(url);
      }, 2000);

      // Mettre à jour la date de dernière sauvegarde
      localStorage.setItem('agora_last_backup_date', now.toString());
      setLastBackupDate(new Date(now).toLocaleString('fr-FR'));
    } catch (e) {
      console.error("Erreur export:", e);
      alert("Erreur lors de la création du fichier de sauvegarde.");
    }
  };

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (e) => {
      try {
        const content = e.target?.result as string;
        const parsed = JSON.parse(content);

        // Support Legacy (v1) and New (v2) formats
        const rawData = parsed.meta ? parsed.data : parsed;
        
        // Analyze content for preview
        const notes = rawData.notes ? JSON.parse(rawData.notes) : [];
        const journal = rawData.journal ? JSON.parse(rawData.journal) : [];
        const seminars = rawData.seminars ? JSON.parse(rawData.seminars) : [];
        const favs = rawData.favorites ? JSON.parse(rawData.favorites) : [];
        const links = rawData.driveLinks ? JSON.parse(rawData.driveLinks) : [];

        setImportPreview({
          notesCount: notes.length,
          journalCount: journal.length,
          seminarCount: seminars.length,
          favoritesCount: favs.length,
          driveLinksCount: links.length,
          date: parsed.meta ? new Date(parsed.meta.exportedAt).toLocaleString('fr-FR') : "Date inconnue (Ancien format)"
        });

        setPendingImportData(rawData);

      } catch (error) {
        alert("Erreur: Le fichier est corrompu ou n'est pas un cartable numérique valide.");
        console.error(error);
      }
    };
    reader.readAsText(file);
    // Reset input to allow selecting the same file again if needed
    event.target.value = '';
  };

  const confirmImport = () => {
    if (!pendingImportData) return;

    const d = pendingImportData;
    if (d.profile) localStorage.setItem('agora_user_profile', d.profile);
    if (d.notes) localStorage.setItem('agora_user_notes', d.notes);
    if (d.journal) localStorage.setItem('agora_journal', d.journal);
    if (d.seminars) localStorage.setItem('agora_seminar_history', d.seminars);
    if (d.favorites) localStorage.setItem('agora_theory_favorites', d.favorites);
    
    // Drive data handling (support legacy keys if needed)
    if (d.driveUrl || d.drive) localStorage.setItem('agora_drive_course_url', d.driveUrl || d.drive);
    if (d.driveLinks) localStorage.setItem('agora_drive_custom_links', d.driveLinks);

    alert("Restauration terminée avec succès !");
    window.location.reload();
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-4xl mx-auto pb-20">
      {/* Header */}
      <div className="bg-[#002147] text-white p-10 rounded-2xl shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none serif text-[10rem]">👤</div>
        <div className="relative z-10">
          <h2 className="text-4xl font-bold serif mb-2">Dossier Administratif</h2>
          <p className="text-blue-200">Gérez votre identité académique et la portabilité de vos données.</p>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        {/* Profile Card */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <div className="flex justify-between items-start mb-6">
            <h3 className="text-xl font-bold text-slate-900 serif">Identité Étudiante</h3>
            <button 
              onClick={() => setIsEditing(!isEditing)}
              className="text-xs font-bold uppercase tracking-widest text-[#003399] hover:text-[#002147]"
            >
              {isEditing ? 'Annuler' : 'Modifier'}
            </button>
          </div>

          {isEditing ? (
            <div className="space-y-4">
              <div>
                <label className="block text-xs font-bold text-slate-400 uppercase mb-1">Pseudonyme</label>
                <input 
                  type="text" 
                  value={editName}
                  onChange={(e) => setEditName(e.target.value)}
                  className="w-full p-3 bg-slate-50 border border-slate-200 rounded-lg text-slate-900 font-bold"
                />
              </div>
              <button 
                onClick={handleSaveProfile}
                className="w-full py-3 bg-[#003399] text-white rounded-lg font-bold shadow-sm hover:bg-[#002147] transition-colors"
              >
                Enregistrer les modifications
              </button>
            </div>
          ) : (
            <div className="flex items-center space-x-6">
              <div className="w-20 h-20 bg-[#002147] rounded-2xl flex items-center justify-center text-3xl font-bold text-white shadow-lg">
                {user.pseudonym.charAt(0).toUpperCase()}
              </div>
              <div>
                <p className="text-2xl font-bold text-slate-900">{user.pseudonym}</p>
                <p className="text-xs text-slate-400 mt-1">Membre depuis le {new Date(user.joinedDate).toLocaleDateString()}</p>
              </div>
            </div>
          )}
        </div>

        {/* Stats Card */}
        <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
          <h3 className="text-xl font-bold text-slate-900 serif mb-6">Activité Académique</h3>
          <div className="grid grid-cols-2 gap-4">
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-3xl font-bold text-[#003399]">{stats.notes}</p>
              <p className="text-xs font-bold uppercase text-slate-400 tracking-widest">Notes crées</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-3xl font-bold text-emerald-600">{stats.journalEntries}</p>
              <p className="text-xs font-bold uppercase text-slate-400 tracking-widest">Entrées Journal</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-3xl font-bold text-amber-600">{stats.seminars}</p>
              <p className="text-xs font-bold uppercase text-slate-400 tracking-widest">Séminaires</p>
            </div>
            <div className="p-4 bg-slate-50 rounded-xl border border-slate-100">
              <p className="text-3xl font-bold text-rose-600">{stats.favorites}</p>
              <p className="text-xs font-bold uppercase text-slate-400 tracking-widest">Concepts</p>
            </div>
          </div>
        </div>
      </div>

      {/* Sync Section - Improved */}
      <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm overflow-hidden relative">
        <div className="relative z-10">
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-xl font-bold text-slate-900 serif">Cartable Numérique</h3>
              <p className="text-slate-500 text-sm">Sauvegardez l'intégralité de vos travaux dans un fichier sécurisé.</p>
            </div>
            {lastBackupDate && (
               <div className="text-right">
                 <span className="text-[10px] font-bold uppercase tracking-widest text-emerald-600 bg-emerald-50 px-2 py-1 rounded-md border border-emerald-100">
                   Dernière sauvegarde : {lastBackupDate}
                 </span>
               </div>
            )}
          </div>

          <div className="flex flex-col md:flex-row gap-4 mt-6">
            <button 
              onClick={handleExport}
              className="flex-1 flex items-center justify-center space-x-3 p-6 bg-[#002147] text-white rounded-xl hover:bg-black transition-all shadow-lg group relative overflow-hidden"
            >
              <div className="absolute inset-0 bg-white/5 opacity-0 group-hover:opacity-100 transition-opacity"></div>
              <span className="text-2xl group-hover:-translate-y-1 transition-transform">💾</span>
              <div className="text-left">
                <span className="block font-bold">Exporter mes données</span>
                <span className="text-[10px] uppercase opacity-70 tracking-widest">Télécharger le fichier .json</span>
              </div>
            </button>

            <div className="flex-1 relative">
              <input
                type="file"
                accept=".json"
                ref={fileInputRef}
                className="hidden"
                onChange={handleFileSelect}
              />
              <button 
                onClick={() => fileInputRef.current?.click()}
                className="w-full h-full flex items-center justify-center space-x-3 p-6 bg-white border-2 border-dashed border-slate-300 text-slate-600 rounded-xl hover:border-[#003399] hover:text-[#003399] hover:bg-slate-50 transition-all group"
              >
                <span className="text-2xl group-hover:-translate-y-1 transition-transform">📂</span>
                <div className="text-left">
                  <span className="block font-bold">Importer une sauvegarde</span>
                  <span className="text-[10px] uppercase opacity-70 tracking-widest">Restaurer depuis un fichier</span>
                </div>
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Logout Zone */}
      <div className="flex justify-center pt-8">
        <button 
          onClick={onLogout}
          className="px-8 py-3 text-red-600 font-bold uppercase text-xs tracking-widest hover:bg-red-50 rounded-lg transition-colors"
        >
          Déconnexion de la session locale
        </button>
      </div>

      {/* Modal de Confirmation d'Import */}
      {importPreview && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm" onClick={() => setImportPreview(null)}></div>
          <div className="bg-white rounded-2xl shadow-2xl max-w-lg w-full relative z-10 overflow-hidden animate-fadeIn">
            <div className="bg-[#003399] p-6 text-white">
              <h3 className="text-lg font-bold serif">Confirmer la restauration</h3>
              <p className="text-blue-100 text-sm">Analyse du fichier de sauvegarde</p>
            </div>
            <div className="p-6">
              <div className="space-y-4 mb-6">
                <div className="bg-slate-50 p-4 rounded-xl border border-slate-100">
                   <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-2">Contenu détecté</p>
                   <div className="grid grid-cols-2 gap-y-2 text-sm text-slate-700">
                     <div className="flex justify-between mr-4"><span>Notes :</span> <span className="font-bold">{importPreview.notesCount}</span></div>
                     <div className="flex justify-between"><span>Séminaires :</span> <span className="font-bold">{importPreview.seminarCount}</span></div>
                     <div className="flex justify-between mr-4"><span>Journal :</span> <span className="font-bold">{importPreview.journalCount}</span></div>
                     <div className="flex justify-between"><span>Concepts :</span> <span className="font-bold">{importPreview.favoritesCount}</span></div>
                     <div className="flex justify-between mr-4"><span>Liens Drive :</span> <span className="font-bold">{importPreview.driveLinksCount}</span></div>
                   </div>
                   <div className="mt-4 pt-3 border-t border-slate-200 text-xs text-slate-500 text-center italic">
                     Fichier exporté le : {importPreview.date}
                   </div>
                </div>
                <div className="p-3 bg-red-50 border border-red-100 rounded-lg flex items-start space-x-3">
                  <span className="text-red-500 text-xl">⚠️</span>
                  <p className="text-xs text-red-800 leading-relaxed">
                    <strong>Attention :</strong> Cette action remplacera toutes les données actuelles de cet appareil par celles contenues dans le fichier. Cette action est irréversible.
                  </p>
                </div>
              </div>
              <div className="flex space-x-3">
                <button 
                  onClick={() => { setImportPreview(null); setPendingImportData(null); }}
                  className="flex-1 py-3 bg-white border border-slate-200 text-slate-600 rounded-xl font-bold hover:bg-slate-50"
                >
                  Annuler
                </button>
                <button 
                  onClick={confirmImport}
                  className="flex-1 py-3 bg-[#003399] text-white rounded-xl font-bold hover:bg-[#002147] shadow-lg"
                >
                  Confirmer la Restauration
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AccountProfile;
