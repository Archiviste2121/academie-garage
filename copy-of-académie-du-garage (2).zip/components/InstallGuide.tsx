
import React, { useState, useEffect } from 'react';

interface InstallGuideProps {
  onClose: () => void;
}

const InstallGuide: React.FC<InstallGuideProps> = ({ onClose }) => {
  const [currentUrl, setCurrentUrl] = useState('');
  const [copied, setCopied] = useState(false);
  const [warningMessage, setWarningMessage] = useState<string | null>(null);
  const [isGitHub, setIsGitHub] = useState(false);

  useEffect(() => {
    // Analyse de l'environnement
    const protocol = window.location.protocol;
    const host = window.location.host;
    const path = window.location.pathname;
    
    if (host.includes('github.io')) {
      setIsGitHub(true);
      setCurrentUrl(`${protocol}//${host}${path}`);
    } else if (protocol === 'file:') {
      setWarningMessage("⚠️ Vous utilisez ce fichier en local (file://). Ce lien ne fonctionnera PAS sur un autre appareil.");
      setCurrentUrl(window.location.href);
    } else if (host.includes('localhost') || host.includes('127.0.0.1')) {
      setWarningMessage("⚠️ Vous êtes en localhost. Le lien ne fonctionnera que sur CET ordinateur.");
      setCurrentUrl(`${protocol}//${host}${path}`);
    } else if (host.includes('usercontent.goog')) {
       // Cloud Shell / IDX preview
       setWarningMessage("⚠️ Lien de prévisualisation Google. Il peut nécessiter une connexion à votre compte Google pour fonctionner sur mobile.");
       setCurrentUrl(`${protocol}//${host}${path}`);
    } else {
       // Production normale
       setCurrentUrl(`${protocol}//${host}${path}`);
    }

  }, []);

  const handleCopy = () => {
    navigator.clipboard.writeText(currentUrl);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleEmail = () => {
    const subject = "Mon accès Académie du Garage";
    const body = `Voici le lien pour accéder à l'application sur mobile :\n\n${currentUrl}\n\nOuvre ce lien directement dans Safari (iPhone) ou Chrome (Android).`;
    window.location.href = `mailto:?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      {/* Backdrop */}
      <div 
        className="absolute inset-0 bg-slate-900/80 backdrop-blur-sm transition-opacity"
        onClick={onClose}
      ></div>

      {/* Modal */}
      <div className="relative bg-white rounded-2xl shadow-2xl max-w-lg w-full overflow-hidden animate-fadeIn">
        <div className="bg-[#002147] p-6 text-white flex justify-between items-center">
          <h3 className="text-xl font-bold serif">{isGitHub ? "Application Web" : "Installation Mobile"}</h3>
          <button onClick={onClose} className="text-white/70 hover:text-white">
            <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M6 18L18 6M6 6l12 12" /></svg>
          </button>
        </div>

        <div className="p-6 space-y-6 max-h-[80vh] overflow-y-auto">
          
          {isGitHub && (
             <div className="bg-emerald-50 border border-emerald-200 rounded-xl p-4 flex items-start space-x-3">
              <span className="text-xl">✅</span>
              <div>
                <p className="text-xs font-bold text-emerald-800 uppercase tracking-widest mb-1">Version Officielle</p>
                <p className="text-sm text-emerald-900 leading-tight">
                  Vous êtes sur la version hébergée par GitHub. Ce lien est permanent et sécurisé.
                </p>
              </div>
            </div>
          )}

          {warningMessage && (
            <div className="bg-red-50 border border-red-200 rounded-xl p-4 flex items-start space-x-3">
              <span className="text-xl">🛑</span>
              <p className="text-xs font-bold text-red-800 leading-relaxed">
                {warningMessage}
              </p>
            </div>
          )}

          {/* Solution Recommandée : Email */}
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-5 text-center space-y-3">
             <h4 className="font-bold text-[#003399] uppercase tracking-widest text-xs">Méthode la plus simple</h4>
             <p className="text-sm text-slate-600">Envoyez-vous le lien par courriel pour l'ouvrir facilement sur votre téléphone.</p>
             <button 
               onClick={handleEmail}
               className="w-full py-3 bg-[#003399] text-white rounded-lg font-bold shadow-md hover:bg-[#002147] transition-colors flex items-center justify-center space-x-2"
             >
               <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M3 8l7.89 5.26a2 2 0 002.22 0L21 8M5 19h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v10a2 2 0 002 2z" /></svg>
               <span>M'envoyer le lien par Email</span>
             </button>
          </div>

          <div className="relative flex py-2 items-center">
            <div className="flex-grow border-t border-slate-200"></div>
            <span className="flex-shrink-0 mx-4 text-slate-400 text-xs font-bold uppercase">Ou copier manuellement</span>
            <div className="flex-grow border-t border-slate-200"></div>
          </div>

          {/* Copie Manuelle */}
          <div className="bg-slate-50 p-4 rounded-xl border border-slate-200">
             <div className="flex gap-2">
               <input 
                 type="text" 
                 readOnly 
                 value={currentUrl} 
                 className="flex-1 bg-white border border-slate-300 rounded-lg px-3 py-2 text-xs text-slate-600 font-mono select-all focus:ring-2 focus:ring-blue-500 outline-none truncate"
               />
               <button 
                 onClick={handleCopy}
                 className="bg-slate-200 text-slate-700 px-4 py-2 rounded-lg text-xs font-bold uppercase tracking-widest hover:bg-slate-300 transition-all flex items-center min-w-[80px] justify-center"
               >
                 {copied ? "Copié !" : "Copier"}
               </button>
             </div>
          </div>

          <div className="h-px bg-slate-100 w-full"></div>

          <div className="space-y-4">
             <h4 className="font-bold text-slate-900 text-sm">Une fois sur mobile :</h4>
            {/* iOS / iPad Instructions */}
            <div className="bg-white p-3 rounded-lg border border-slate-100 flex items-start space-x-3">
               <span className="text-xl">🍎</span>
               <div className="text-xs text-slate-600">
                 <strong>iPhone (Safari) :</strong> Bouton Partager <span className="inline-block px-1 bg-slate-100 border rounded">⎋</span> &rarr; "Sur l'écran d'accueil".
               </div>
            </div>

            {/* Android Instructions */}
            <div className="bg-white p-3 rounded-lg border border-slate-100 flex items-start space-x-3">
               <span className="text-xl">🤖</span>
               <div className="text-xs text-slate-600">
                 <strong>Android (Chrome) :</strong> Menu <span className="inline-block px-1 bg-slate-100 border rounded">⋮</span> &rarr; "Ajouter à l'écran d'accueil".
               </div>
            </div>
          </div>

          <div className="text-center pt-2">
            <button 
              onClick={onClose}
              className="text-slate-400 hover:text-slate-600 text-sm font-medium underline"
            >
              Fermer la fenêtre
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default InstallGuide;
