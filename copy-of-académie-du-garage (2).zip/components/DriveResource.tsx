
import React, { useState, useEffect } from 'react';

interface CustomResource {
  id: string;
  title: string;
  url: string;
  addedAt: number;
}

const DriveResource: React.FC = () => {
  const [courseFolderUrl, setCourseFolderUrl] = useState('');
  const [isEditing, setIsEditing] = useState(false);
  const [customResources, setCustomResources] = useState<CustomResource[]>([]);
  
  // États pour l'ajout de nouveau fichier
  const [newResTitle, setNewResTitle] = useState('');
  const [newResUrl, setNewResUrl] = useState('');

  useEffect(() => {
    const savedUrl = localStorage.getItem('agora_drive_course_url');
    if (savedUrl) setCourseFolderUrl(savedUrl);

    const savedResources = localStorage.getItem('agora_drive_custom_links');
    if (savedResources) setCustomResources(JSON.parse(savedResources));
  }, []);

  const saveUrl = () => {
    localStorage.setItem('agora_drive_course_url', courseFolderUrl);
    setIsEditing(false);
  };

  const addResource = () => {
    if (!newResTitle.trim() || !newResUrl.trim()) return;
    
    const newResource: CustomResource = {
      id: Date.now().toString(),
      title: newResTitle,
      url: newResUrl,
      addedAt: Date.now()
    };

    const updated = [newResource, ...customResources];
    setCustomResources(updated);
    localStorage.setItem('agora_drive_custom_links', JSON.stringify(updated));
    setNewResTitle('');
    setNewResUrl('');
  };

  const removeResource = (id: string) => {
    const updated = customResources.filter(r => r.id !== id);
    setCustomResources(updated);
    localStorage.setItem('agora_drive_custom_links', JSON.stringify(updated));
  };

  const getFileIcon = (url: string) => {
    const lowerUrl = url.toLowerCase();
    
    // Détection par extension ou mot-clé d'URL
    if (lowerUrl.includes('.pdf')) return '📕';
    if (lowerUrl.includes('.doc') || lowerUrl.includes('docs.google.com/document')) return '📘';
    if (lowerUrl.includes('.xls') || lowerUrl.includes('.csv') || lowerUrl.includes('docs.google.com/spreadsheets')) return '📗';
    if (lowerUrl.includes('.ppt') || lowerUrl.includes('docs.google.com/presentation')) return '📙';
    if (lowerUrl.includes('.txt')) return '📄';
    if (lowerUrl.includes('.jpg') || lowerUrl.includes('.png') || lowerUrl.includes('.jpeg')) return '🖼️';
    if (lowerUrl.includes('youtube') || lowerUrl.includes('youtu.be')) return '▶️';
    if (lowerUrl.includes('drive.google.com/drive/folders')) return '📂';
    
    return '🔗'; // Par défaut
  };

  const openDrive = (path: string = '') => {
    window.open(`https://drive.google.com/drive/${path}`, '_blank');
  };

  const openUrl = (url: string) => {
    if (!url) return;
    const finalUrl = url.startsWith('http') ? url : `https://${url}`;
    window.open(finalUrl, '_blank');
  };

  const quickAccess = [
    { title: "Mon Drive", icon: "📁", action: () => openDrive('my-drive'), desc: "Accès racine à vos documents personnels." },
    { title: "Partagés avec moi", icon: "👥", action: () => openDrive('shared-with-me'), desc: "Travaux de groupe et documents professeurs." },
    { title: "Documents Récents", icon: "🕒", action: () => openDrive('recent'), desc: "Reprendre le travail en cours." },
    { title: "Google Scholar", icon: "🎓", action: () => window.open('https://scholar.google.ca/', '_blank'), desc: "Recherche d'articles académiques." },
  ];

  return (
    <div className="space-y-10 animate-fadeIn max-w-5xl mx-auto pb-20">
      {/* Header */}
      <div className="bg-[#002147] text-white p-10 rounded-2xl shadow-xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none serif text-[8rem]">☁️</div>
        <div className="relative z-10 max-w-2xl space-y-4">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-blue-500/20 border border-blue-400/30 text-blue-200 text-[10px] font-black uppercase tracking-widest">
            <span className="w-1.5 h-1.5 rounded-full bg-blue-400"></span>
            <span>Ressources Cloud</span>
          </div>
          <h2 className="text-4xl font-bold serif leading-tight">Dépôt Numérique</h2>
          <p className="text-blue-100 text-lg font-medium leading-relaxed opacity-90">
            Centralisez vos lectures, vos travaux de session et accédez à l'écosystème Google Drive sans quitter votre environnement d'étude.
          </p>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        {/* Section Principale - Dossier Cours */}
        <div className="lg:col-span-2 space-y-8">
          {/* Course Folder Shortcut */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
              <div>
                <h3 className="text-xl font-bold text-slate-900 serif">Dossier de Cours Principal</h3>
                <p className="text-sm text-slate-500 mt-1">Accès rapide au répertoire Google Drive du semestre.</p>
              </div>
              <button 
                onClick={() => setIsEditing(!isEditing)}
                className="text-xs font-bold uppercase tracking-widest text-[#003399] hover:text-[#002147] transition-colors"
              >
                {isEditing ? 'Annuler' : 'Configurer'}
              </button>
            </div>

            {isEditing ? (
              <div className="flex gap-4 animate-fadeIn">
                <input 
                  type="text" 
                  className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl text-sm focus:ring-1 focus:ring-[#002147] outline-none"
                  placeholder="Collez le lien Google Drive ici..."
                  value={courseFolderUrl}
                  onChange={(e) => setCourseFolderUrl(e.target.value)}
                />
                <button 
                  onClick={saveUrl}
                  className="bg-[#003399] text-white px-6 py-2 rounded-xl font-bold text-sm hover:bg-[#002147] transition-colors"
                >
                  Sauvegarder
                </button>
              </div>
            ) : (
              <div className="flex items-center p-6 bg-blue-50 rounded-xl border border-blue-100 group cursor-pointer hover:bg-blue-100 transition-colors" onClick={() => openUrl(courseFolderUrl)}>
                <div className="w-12 h-12 bg-white rounded-lg flex items-center justify-center text-2xl border border-blue-200 mr-4 shadow-sm group-hover:scale-110 transition-transform">
                  {getFileIcon(courseFolderUrl)}
                </div>
                <div className="flex-1">
                  {courseFolderUrl ? (
                    <>
                      <p className="font-bold text-[#002147] text-lg group-hover:underline decoration-[#003399]">Ouvrir le dossier</p>
                      <p className="text-xs text-blue-800/60 truncate max-w-md">{courseFolderUrl}</p>
                    </>
                  ) : (
                    <p className="font-bold text-slate-400 italic">Aucun lien configuré.</p>
                  )}
                </div>
                {courseFolderUrl && (
                  <div className="text-[#003399]">
                    <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" /></svg>
                  </div>
                )}
              </div>
            )}
          </div>

          {/* Bibliographie & Fichiers Spécifiques */}
          <div className="bg-white p-8 rounded-2xl border border-slate-200 shadow-sm">
            <h3 className="text-xl font-bold text-slate-900 serif mb-6">Bibliographie & Documents</h3>
            
            {/* Formulaire d'ajout */}
            <div className="bg-slate-50 p-4 rounded-xl border border-slate-200 mb-6 space-y-3">
              <input 
                type="text" 
                placeholder="Titre du document (ex: Syllabus, Lecture Semaine 1)"
                className="w-full p-3 bg-white border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-[#002147] outline-none"
                value={newResTitle}
                onChange={(e) => setNewResTitle(e.target.value)}
              />
              <div className="flex gap-3">
                <input 
                  type="text" 
                  placeholder="URL du fichier (PDF, Doc, Link...)"
                  className="flex-1 p-3 bg-white border border-slate-200 rounded-lg text-sm focus:ring-1 focus:ring-[#002147] outline-none"
                  value={newResUrl}
                  onChange={(e) => setNewResUrl(e.target.value)}
                />
                <button 
                  onClick={addResource}
                  disabled={!newResTitle || !newResUrl}
                  className="bg-slate-900 text-white px-6 rounded-lg font-bold text-sm hover:bg-black transition-colors disabled:opacity-50"
                >
                  Ajouter
                </button>
              </div>
            </div>

            {/* Liste des fichiers */}
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {customResources.length === 0 ? (
                <div className="col-span-full text-center py-8 text-slate-400 italic text-sm">
                  Aucun document ajouté. Ajoutez vos liens PDF, DOCX ou articles ici.
                </div>
              ) : (
                customResources.map((res) => (
                  <div key={res.id} className="group relative flex items-center p-4 bg-white border border-slate-100 rounded-xl hover:border-[#003399] hover:shadow-md transition-all">
                    <div className="w-10 h-10 flex items-center justify-center text-2xl bg-slate-50 rounded-lg mr-3 shrink-0 group-hover:bg-blue-50 transition-colors">
                      {getFileIcon(res.url)}
                    </div>
                    <div className="flex-1 min-w-0 cursor-pointer" onClick={() => openUrl(res.url)}>
                      <h4 className="font-bold text-slate-800 text-sm truncate group-hover:text-[#003399]">{res.title}</h4>
                      <p className="text-[10px] text-slate-400 truncate">{new URL(res.url.startsWith('http') ? res.url : `https://${res.url}`).hostname}</p>
                    </div>
                    <button 
                      onClick={() => removeResource(res.id)}
                      className="ml-2 p-1.5 text-slate-300 hover:text-red-500 rounded-full hover:bg-red-50 transition-colors opacity-0 group-hover:opacity-100"
                    >
                      <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" /></svg>
                    </button>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Sidebar - Quick Access */}
        <div>
          <h3 className="text-lg font-bold text-slate-900 serif mb-6 flex items-center">
            <span className="w-8 h-px bg-slate-300 mr-3"></span>Accès Rapide
          </h3>
          <div className="grid grid-cols-1 gap-4">
            {quickAccess.map((res, idx) => (
              <button
                key={idx}
                onClick={res.action}
                className="bg-white p-5 rounded-2xl border border-slate-200 text-left hover:border-[#003399] hover:shadow-lg transition-all group flex items-start space-x-4"
              >
                <div className="text-3xl grayscale group-hover:grayscale-0 transition-all duration-300">{res.icon}</div>
                <div>
                  <h4 className="font-bold text-slate-900 text-base mb-1 group-hover:text-[#003399] transition-colors">{res.title}</h4>
                  <p className="text-xs text-slate-500 leading-relaxed">{res.desc}</p>
                </div>
              </button>
            ))}
          </div>
          
          <div className="mt-8 p-6 bg-slate-50 rounded-2xl border border-slate-200">
             <h4 className="font-bold text-xs uppercase tracking-widest text-slate-500 mb-3">Légende des Icônes</h4>
             <div className="grid grid-cols-2 gap-2 text-[10px] text-slate-600 font-medium">
               <div className="flex items-center"><span className="mr-2 text-base">📕</span> PDF</div>
               <div className="flex items-center"><span className="mr-2 text-base">📘</span> Word / Doc</div>
               <div className="flex items-center"><span className="mr-2 text-base">📗</span> Excel / CSV</div>
               <div className="flex items-center"><span className="mr-2 text-base">📙</span> PowerPoint</div>
               <div className="flex items-center"><span className="mr-2 text-base">🖼️</span> Image</div>
               <div className="flex items-center"><span className="mr-2 text-base">▶️</span> Vidéo</div>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default DriveResource;
