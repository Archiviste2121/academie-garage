
import React, { useState, useEffect } from 'react';
import { UserNote } from '../types';

const NotesManager: React.FC = () => {
  const [notes, setNotes] = useState<UserNote[]>([]);
  const [activeNoteId, setActiveNoteId] = useState<string | null>(null);
  const [isMobileListVisible, setIsMobileListVisible] = useState(true);

  useEffect(() => {
    const savedNotes = localStorage.getItem('agora_user_notes');
    if (savedNotes) {
      setNotes(JSON.parse(savedNotes));
    }
  }, []);

  const saveNotes = (updatedNotes: UserNote[]) => {
    setNotes(updatedNotes);
    localStorage.setItem('agora_user_notes', JSON.stringify(updatedNotes));
  };

  const createNote = () => {
    const newNote: UserNote = {
      id: Date.now().toString(),
      title: 'Nouvelle Note',
      content: '',
      lastModified: Date.now()
    };
    saveNotes([newNote, ...notes]);
    setActiveNoteId(newNote.id);
    setIsMobileListVisible(false);
  };

  const updateNote = (id: string, updates: Partial<UserNote>) => {
    const updated = notes.map(n => 
      n.id === id ? { ...n, ...updates, lastModified: Date.now() } : n
    );
    saveNotes(updated);
  };

  const deleteNote = (id: string) => {
    if (confirm('Supprimer cette note ?')) {
      const updated = notes.filter(n => n.id !== id);
      saveNotes(updated);
      if (activeNoteId === id) {
        setActiveNoteId(null);
        setIsMobileListVisible(true);
      }
    }
  };

  const activeNote = notes.find(n => n.id === activeNoteId);

  return (
    <div className="flex flex-col md:flex-row h-[calc(100dvh-7rem)] lg:h-[calc(100vh-8rem)] gap-4 md:gap-6 animate-fadeIn relative">
      {/* Sidebar des notes (Liste) - Mobile : visible si isMobileListVisible est true */}
      <div className={`w-full md:w-72 flex flex-col space-y-4 ${isMobileListVisible ? 'flex' : 'hidden md:flex'}`}>
        <div className="flex items-center justify-between">
          <h2 className="text-2xl font-bold serif text-slate-800">Mes Notes</h2>
          <button 
            onClick={createNote}
            className="p-2 bg-amber-600 text-white rounded-full hover:bg-amber-700 transition-colors shadow-sm"
            title="Nouvelle note"
          >
            <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 4v16m8-8H4" />
            </svg>
          </button>
        </div>

        <div className="flex-1 overflow-y-auto space-y-2 pr-2">
          {notes.length === 0 ? (
            <div className="text-center py-10 px-4 bg-white border border-dashed border-slate-300 rounded-xl">
              <p className="text-sm text-slate-400">Aucune note. <br/> Commencez à rédiger vos fiches de révision.</p>
            </div>
          ) : (
            notes.sort((a,b) => b.lastModified - a.lastModified).map(note => (
              <button
                key={note.id}
                onClick={() => {
                  setActiveNoteId(note.id);
                  setIsMobileListVisible(false);
                }}
                className={`w-full text-left p-4 rounded-xl transition-all duration-200 border ${
                  activeNoteId === note.id 
                  ? 'bg-amber-50 border-amber-300 shadow-sm ring-1 ring-amber-200' 
                  : 'bg-white border-slate-200 hover:border-amber-200 hover:bg-slate-50'
                }`}
              >
                <h4 className="font-bold text-slate-800 truncate">{note.title}</h4>
                <p className="text-xs text-slate-400 mt-1">
                  {new Date(note.lastModified).toLocaleDateString()}
                </p>
                <p className="text-xs text-slate-500 mt-2 line-clamp-2 italic">
                  {note.content.substring(0, 60) || "Pas de contenu..."}
                </p>
              </button>
            ))
          )}
        </div>
      </div>

      {/* Éditeur - Mobile : visible si isMobileListVisible est false */}
      <div className={`flex-1 bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden flex flex-col ${!isMobileListVisible ? 'flex' : 'hidden md:flex'}`}>
        {activeNote ? (
          <>
            <div className="p-4 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <div className="flex items-center flex-1 gap-2">
                <button 
                  onClick={() => setIsMobileListVisible(true)}
                  className="md:hidden text-slate-400 hover:text-slate-700"
                >
                   <svg className="w-6 h-6" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M15 19l-7-7 7-7" /></svg>
                </button>
                <input 
                  type="text"
                  className="bg-transparent border-none text-lg md:text-xl font-bold text-slate-800 focus:ring-0 w-full serif"
                  value={activeNote.title}
                  onChange={(e) => updateNote(activeNote.id, { title: e.target.value })}
                  placeholder="Titre de la note..."
                />
              </div>
              <button 
                onClick={() => deleteNote(activeNote.id)}
                className="text-slate-400 hover:text-red-500 p-2 transition-colors"
              >
                <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                </svg>
              </button>
            </div>
            <textarea
              className="flex-1 p-6 md:p-8 text-slate-700 leading-relaxed focus:ring-0 border-none resize-none font-sans text-base md:text-lg bg-[url('https://www.transparenttextures.com/patterns/lined-paper.png')] bg-fixed"
              value={activeNote.content}
              onChange={(e) => updateNote(activeNote.id, { content: e.target.value })}
              placeholder="Écrivez vos pensées, théories ou résumés de cours ici..."
            />
          </>
        ) : (
          <div className="flex-1 flex flex-col items-center justify-center text-slate-400 p-10 text-center">
            <div className="w-20 h-20 bg-slate-50 rounded-full flex items-center justify-center mb-4">
              <span className="text-4xl">📝</span>
            </div>
            <h3 className="text-xl font-bold text-slate-600 serif">Sélecteur de Notes</h3>
            <p className="max-w-xs mt-2">Choisissez une note dans la liste ou créez-en une nouvelle pour commencer vos révisions.</p>
            <button 
              onClick={() => setIsMobileListVisible(true)}
              className="mt-4 md:hidden text-amber-600 font-bold"
            >
              Retour à la liste
            </button>
          </div>
        )}
      </div>
    </div>
  );
};

export default NotesManager;
