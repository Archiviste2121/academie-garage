
import React, { useState, useEffect } from 'react';
import { JournalEntry } from '../types';

const StudyJournal: React.FC = () => {
  const [entries, setEntries] = useState<JournalEntry[]>([]);
  const [newEntryContent, setNewEntryContent] = useState('');
  const [selectedMood, setSelectedMood] = useState<JournalEntry['mood']>('inspired');

  useEffect(() => {
    const saved = localStorage.getItem('agora_journal');
    if (saved) setEntries(JSON.parse(saved));
  }, []);

  const saveJournal = (newEntries: JournalEntry[]) => {
    setEntries(newEntries);
    localStorage.setItem('agora_journal', JSON.stringify(newEntries));
  };

  const addEntry = () => {
    if (!newEntryContent.trim()) return;
    const entry: JournalEntry = {
      id: Date.now().toString(),
      date: Date.now(),
      content: newEntryContent,
      mood: selectedMood
    };
    saveJournal([entry, ...entries]);
    setNewEntryContent('');
  };

  const deleteEntry = (id: string) => {
    if (confirm('Supprimer cette entrée ?')) {
      saveJournal(entries.filter(e => e.id !== id));
    }
  };

  const moods = {
    inspired: { icon: '💡', label: 'Inspiré', color: 'bg-amber-100 text-amber-700 border-amber-200' },
    productive: { icon: '🔥', label: 'Productif', color: 'bg-emerald-100 text-emerald-700 border-emerald-200' },
    tired: { icon: '💤', label: 'Fatigué', color: 'bg-blue-100 text-blue-700 border-blue-200' },
    stressed: { icon: '🤯', label: 'Stressé', color: 'bg-rose-100 text-rose-700 border-rose-200' }
  };

  return (
    <div className="space-y-8 animate-fadeIn max-w-3xl mx-auto">
      <header className="text-center space-y-2">
        <h2 className="text-4xl font-bold serif text-slate-800">Journal de bord</h2>
        <p className="text-slate-500">Documentez votre parcours académique et vos réflexions quotidiennes.</p>
      </header>

      {/* Saisie d'entrée */}
      <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200 space-y-4">
        <textarea
          className="w-full p-4 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-amber-500 focus:border-transparent outline-none min-h-[120px] transition-all"
          placeholder="Qu'avez-vous appris aujourd'hui ? Quelles sont vos réflexions sur le cours de géopolitique ?"
          value={newEntryContent}
          onChange={(e) => setNewEntryContent(e.target.value)}
        />
        <div className="flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center space-x-2">
            <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mr-2">Humeur :</span>
            {(Object.entries(moods) as [JournalEntry['mood'], typeof moods['inspired']][]).map(([key, data]) => (
              <button
                key={key}
                onClick={() => setSelectedMood(key)}
                className={`flex items-center space-x-1 px-3 py-1.5 rounded-full text-xs font-medium transition-all border ${
                  selectedMood === key 
                  ? `${data.color} ring-2 ring-offset-1 ring-amber-400` 
                  : 'bg-white text-slate-500 border-slate-100 hover:bg-slate-50'
                }`}
              >
                <span>{data.icon}</span>
                <span>{data.label}</span>
              </button>
            ))}
          </div>
          <button
            onClick={addEntry}
            className="px-6 py-2 bg-slate-900 text-white rounded-xl font-bold hover:bg-black transition-all shadow-md disabled:opacity-50"
            disabled={!newEntryContent.trim()}
          >
            Publier dans le journal
          </button>
        </div>
      </div>

      {/* Liste des entrées */}
      <div className="space-y-6 relative before:absolute before:inset-0 before:ml-5 before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-slate-200 before:to-transparent">
        {entries.length === 0 ? (
          <div className="text-center py-20 opacity-40 grayscale italic">
            <span className="text-6xl mb-4 block">📭</span>
            Votre journal est vide. La mémoire politique commence ici.
          </div>
        ) : (
          entries.map((entry) => (
            <div key={entry.id} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group">
              {/* Point de la timeline */}
              <div className="flex items-center justify-center w-10 h-10 rounded-full border border-white bg-slate-100 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                <span className="text-sm">{entry.mood ? moods[entry.mood].icon : '📅'}</span>
              </div>
              
              {/* Carte d'entrée */}
              <div className="w-[calc(100%-4rem)] md:w-[calc(50%-2.5rem)] bg-white p-6 rounded-2xl shadow-sm border border-slate-200 hover:shadow-md transition-shadow">
                <div className="flex items-center justify-between mb-3">
                  <time className="font-bold text-amber-700 text-sm">
                    {new Date(entry.date).toLocaleDateString('fr-FR', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
                  </time>
                  <button 
                    onClick={() => deleteEntry(entry.id)}
                    className="opacity-0 group-hover:opacity-100 p-1 text-slate-300 hover:text-red-500 transition-all"
                  >
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M19 7l-.867 12.142A2 2 0 0116.138 21H7.862a2 2 0 01-1.995-1.858L5 7m5 4v6m4-6v6m1-10V4a1 1 0 00-1-1h-4a1 1 0 00-1 1v3M4 7h16" />
                    </svg>
                  </button>
                </div>
                <div className="text-slate-700 leading-relaxed whitespace-pre-wrap font-medium">
                  {entry.content}
                </div>
                {entry.mood && (
                  <div className="mt-4 pt-3 border-t border-slate-50 flex">
                    <span className={`text-[10px] uppercase font-bold px-2 py-0.5 rounded-md ${moods[entry.mood].color}`}>
                      Feeling {moods[entry.mood].label}
                    </span>
                  </div>
                )}
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
};

export default StudyJournal;
