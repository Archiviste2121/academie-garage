
import React, { useState, useRef, useEffect } from 'react';
import { GoogleGenAI, Modality } from "@google/genai";
import { ChatMessage } from '../types';

// Utilitaires de décodage audio
function decode(base64: string) {
  const binaryString = window.atob(base64);
  const len = binaryString.length;
  const bytes = new Uint8Array(len);
  for (let i = 0; i < len; i++) {
    bytes[i] = binaryString.charCodeAt(i);
  }
  return bytes;
}

async function decodeAudioData(
  data: Uint8Array,
  ctx: AudioContext,
  sampleRate: number,
  numChannels: number,
): Promise<AudioBuffer> {
  const dataInt16 = new Int16Array(data.buffer, data.byteOffset, data.byteLength / 2);
  const frameCount = dataInt16.length / numChannels;
  const buffer = ctx.createBuffer(numChannels, frameCount, sampleRate);

  for (let channel = 0; channel < numChannels; channel++) {
    const channelData = buffer.getChannelData(channel);
    for (let i = 0; i < frameCount; i++) {
      channelData[i] = dataInt16[i * numChannels + channel] / 32768.0;
    }
  }
  return buffer;
}

const ResearchAssistant: React.FC = () => {
  const [sourceText, setSourceText] = useState('');
  const [chatHistory, setChatHistory] = useState<ChatMessage[]>([]);
  const [input, setInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);
  
  const [audioLoading, setAudioLoading] = useState(false);
  const [isPlaying, setIsPlaying] = useState(false);
  
  const audioContextRef = useRef<AudioContext | null>(null);
  const sourceNodeRef = useRef<AudioBufferSourceNode | null>(null);

  // Fonction pour générer l'Audio Overview
  const generateAudioOverview = async () => {
    if (!sourceText.trim()) return;
    setAudioLoading(true);
    
    // Stop audio s'il joue déjà
    if (sourceNodeRef.current) {
        sourceNodeRef.current.stop();
        setIsPlaying(false);
    }

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      
      const prompt = `Génère un épisode de podcast audio court (environ 1 à 2 minutes) très dynamique en français.
      
      Contexte : Deux animateurs, Kore (l'experte analytique) et Fenrir (le présentateur curieux et énergique), discutent du texte fourni par l'utilisateur.
      
      Style :
      - Ton conversationnel, naturel, avec des hésitations légères et de l'enthousiasme.
      - Fenrir pose des questions naïves mais pertinentes.
      - Kore explique les concepts avec des analogies brillantes.
      - L'objectif est de vulgariser le contenu source tout en restant fidèle aux idées.
      
      Source à analyser : "${sourceText.substring(0, 15000)}"`;

      const response = await ai.models.generateContent({
        model: "gemini-2.5-flash-preview-tts",
        contents: [{ parts: [{ text: prompt }] }],
        config: {
          responseModalities: [Modality.AUDIO],
          speechConfig: {
              multiSpeakerVoiceConfig: {
                speakerVoiceConfigs: [
                      {
                          speaker: 'Kore',
                          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Kore' } }
                      },
                      {
                          speaker: 'Fenrir',
                          voiceConfig: { prebuiltVoiceConfig: { voiceName: 'Fenrir' } }
                      }
                ]
              }
          }
        }
      });

      const base64Audio = response.candidates?.[0]?.content?.parts?.[0]?.inlineData?.data;
      if (base64Audio) {
        playAudio(base64Audio);
      } else {
        alert("Impossible de générer l'audio. Le texte est peut-être trop complexe ou le service saturé.");
      }

    } catch (error) {
      console.error("Erreur TTS:", error);
      alert("Erreur lors de la génération du podcast.");
    } finally {
      setAudioLoading(false);
    }
  };

  const playAudio = async (base64: string) => {
      try {
        if (!audioContextRef.current) {
            audioContextRef.current = new (window.AudioContext || (window as any).webkitAudioContext)({sampleRate: 24000});
        }
        const ctx = audioContextRef.current;
        if (ctx.state === 'suspended') await ctx.resume();

        const audioBuffer = await decodeAudioData(decode(base64), ctx, 24000, 1);
        
        const source = ctx.createBufferSource();
        source.buffer = audioBuffer;
        source.connect(ctx.destination);
        source.onended = () => setIsPlaying(false);
        
        source.start();
        sourceNodeRef.current = source;
        setIsPlaying(true);
      } catch (e) {
          console.error("Erreur lecture audio", e);
      }
  };

  const stopAudio = () => {
      if (sourceNodeRef.current) {
          sourceNodeRef.current.stop();
          setIsPlaying(false);
      }
  };

  const handleChat = async () => {
    if (!input.trim() || !sourceText.trim()) return;
    
    const userMsg: ChatMessage = {
        id: Date.now().toString(),
        role: 'user',
        text: input,
        timestamp: Date.now()
    };
    setChatHistory(prev => [...prev, userMsg]);
    setInput('');
    setChatLoading(true);

    try {
        const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
        const response = await ai.models.generateContent({
            model: 'gemini-3-flash-preview',
            contents: `Tu es un assistant de recherche strict. Tu dois répondre à la question de l'utilisateur EN TE BASANT UNIQUEMENT sur le contexte fourni ci-dessous.
            
            CONTEXTE SOURCE :
            "${sourceText.substring(0, 30000)}"
            
            QUESTION UTILISATEUR :
            "${userMsg.text}"
            
            Si la réponse n'est pas dans le texte, dis-le clairement. Cite les passages pertinents si possible.`,
        });

        const text = response.text || "Désolé, je n'ai pas pu extraire de réponse du contexte.";
        
        setChatHistory(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: text,
            timestamp: Date.now()
        }]);

    } catch (e) {
        console.error(e);
        setChatHistory(prev => [...prev, {
            id: (Date.now() + 1).toString(),
            role: 'model',
            text: "Erreur lors de l'analyse du document.",
            timestamp: Date.now()
        }]);
    } finally {
        setChatLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[calc(100dvh-7rem)] lg:h-[calc(100vh-8rem)] gap-6 animate-fadeIn">
      <div className="shrink-0 flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h2 className="text-3xl font-bold serif text-slate-900">Assistant Documentaire</h2>
            <p className="text-slate-500 text-sm">Analysez vos sources et écoutez des synthèses (façon NotebookLM).</p>
          </div>
          <div className="flex items-center space-x-2">
            {!isPlaying ? (
                <button 
                    onClick={generateAudioOverview}
                    disabled={audioLoading || !sourceText}
                    className="flex items-center space-x-2 px-6 py-3 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-all shadow-lg disabled:opacity-50 disabled:cursor-not-allowed"
                >
                    {audioLoading ? (
                        <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin"></div>
                    ) : (
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M19.114 5.636a9 9 0 010 12.728M16.463 8.288a5.25 5.25 0 010 7.424M6.75 8.25l4.72-4.72a.75.75 0 011.28.53v15.88a.75.75 0 01-1.28.53l-4.72-4.72H4.51c-.88 0-1.704-.507-1.938-1.354A9.01 9.01 0 012.25 12c0-.83.112-1.633.322-2.396C2.806 8.756 3.63 8.25 4.51 8.25H6.75z" /></svg>
                    )}
                    <span>Générer l'Audio Overview</span>
                </button>
            ) : (
                <button 
                    onClick={stopAudio}
                    className="flex items-center space-x-2 px-6 py-3 bg-rose-500 text-white rounded-xl font-bold hover:bg-rose-600 transition-all shadow-lg animate-pulse"
                >
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={2} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M5.25 7.5A2.25 2.25 0 017.5 5.25h9a2.25 2.25 0 012.25 2.25v9a2.25 2.25 0 01-2.25 2.25h-9a2.25 2.25 0 01-2.25-2.25v-9z" /></svg>
                    <span>Arrêter le Podcast</span>
                </button>
            )}
          </div>
      </div>

      <div className="flex-1 grid grid-cols-1 lg:grid-cols-2 gap-6 min-h-0">
        {/* Colonne Gauche : Source */}
        <div className="flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex items-center space-x-2">
                <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-slate-500"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500">Documents Sources</h3>
            </div>
            <textarea 
                className="flex-1 p-6 resize-none outline-none text-sm leading-relaxed text-slate-700 font-mono bg-slate-50/30"
                placeholder="Collez ici le contenu de vos cours, articles ou notes de lecture pour les analyser..."
                value={sourceText}
                onChange={(e) => setSourceText(e.target.value)}
            />
            <div className="p-2 bg-slate-50 border-t border-slate-200 text-right">
                <span className="text-[10px] text-slate-400 font-medium px-2">
                    {sourceText.length} caractères
                </span>
            </div>
        </div>

        {/* Colonne Droite : Chat */}
        <div className="flex flex-col bg-white rounded-2xl border border-slate-200 shadow-sm overflow-hidden">
            <div className="p-4 bg-slate-50 border-b border-slate-200 flex justify-between items-center">
                <div className="flex items-center space-x-2">
                    <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-4 h-4 text-slate-500"><path strokeLinecap="round" strokeLinejoin="round" d="M7.5 8.25h9m-9 3H12m-9.75 1.51c0 1.6 1.123 2.994 2.707 3.227 1.129.166 2.27.293 3.423.379.35.026.67.21.865.501L12 21l2.755-4.133a1.14 1.14 0 01.865-.501 48.172 48.172 0 003.423-.379c1.584-.233 2.707-1.626 2.707-3.228V6.741c0-1.602-1.123-2.995-2.707-3.228A48.394 48.394 0 0012 3c-2.392 0-4.744.175-7.043.513C3.373 3.746 2.25 5.14 2.25 6.741v6.018z" /></svg>
                    <h3 className="text-xs font-bold uppercase tracking-widest text-slate-500">Q&A Contextuel</h3>
                </div>
                <button onClick={() => setChatHistory([])} className="text-[10px] text-slate-400 hover:text-red-500">Effacer</button>
            </div>
            
            <div className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
                {chatHistory.length === 0 && (
                    <div className="h-full flex flex-col items-center justify-center text-slate-300 space-y-2">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M8.625 12a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H8.25m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0H12m4.125 0a.375.375 0 11-.75 0 .375.375 0 01.75 0zm0 0h-.375M21 12c0 4.556-4.03 8.25-9 8.25a9.764 9.764 0 01-2.555-.337A5.972 5.972 0 015.41 20.97a5.969 5.969 0 01-.474-.065 4.48 4.48 0 00.978-2.025c.09-.457-.133-.901-.467-1.226C3.93 16.178 3 14.189 3 12c0-4.556 4.03-8.25 9-8.25s9 3.694 9 8.25z" /></svg>
                        <p className="text-sm">Posez une question sur le texte à gauche.</p>
                    </div>
                )}
                {chatHistory.map((msg, i) => (
                    <div key={i} className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                         <div className={`max-w-[85%] p-3 rounded-xl text-sm ${
                             msg.role === 'user' 
                             ? 'bg-[#002147] text-white rounded-br-none' 
                             : 'bg-white border border-slate-200 text-slate-800 rounded-bl-none shadow-sm'
                         }`}>
                             {msg.text}
                         </div>
                    </div>
                ))}
                {chatLoading && (
                    <div className="flex justify-start">
                        <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
                           <div className="flex space-x-1">
                               <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
                               <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-100"></div>
                               <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce delay-200"></div>
                           </div>
                        </div>
                    </div>
                )}
            </div>

            <div className="p-4 bg-white border-t border-slate-200">
                <div className="flex gap-2">
                    <input 
                        type="text" 
                        value={input}
                        onChange={(e) => setInput(e.target.value)}
                        onKeyDown={(e) => e.key === 'Enter' && handleChat()}
                        placeholder="Interrogez vos documents..."
                        className="flex-1 bg-slate-50 border border-slate-200 rounded-lg px-4 py-2 text-sm focus:ring-1 focus:ring-indigo-500 outline-none"
                    />
                    <button 
                        onClick={handleChat}
                        disabled={chatLoading || !sourceText}
                        className="bg-[#002147] text-white px-4 py-2 rounded-lg font-bold text-xs hover:bg-black transition-colors disabled:opacity-50"
                    >
                        Envoyer
                    </button>
                </div>
            </div>
        </div>
      </div>
    </div>
  );
};

export default ResearchAssistant;
