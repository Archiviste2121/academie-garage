
import React from 'react';
import { AppView, UserProfile } from '../types';

interface DashboardProps {
  onNavigate: (view: AppView) => void;
  user: UserProfile;
  onShowInstall: () => void;
}

const Dashboard: React.FC<DashboardProps> = ({ onNavigate, user, onShowInstall }) => {
  const cards = [
    {
      title: "Codex Théorique",
      desc: "Étude critique des grands paradigmes de la science politique classique et contemporaine.",
      view: AppView.THEORY_EXPLORER,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" /></svg>,
      meta: "Base de données exégétique"
    },
    {
      title: "Assistant Documentaire",
      desc: "Importez vos cours pour générer des synthèses et des podcasts audio (façon NotebookLM).",
      view: AppView.RESEARCH_ASSISTANT,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M9.813 15.904L9 18.75l-.813-2.846a4.5 4.5 0 00-3.09-3.09L2.25 12l2.846-.813a4.5 4.5 0 003.09-3.09L9 5.25l.813 2.846a4.5 4.5 0 003.09 3.09L15.75 12l-2.846.813a4.5 4.5 0 00-3.09 3.09zM18.259 8.715L18 9.75l-.259-1.035a3.375 3.375 0 00-2.455-2.456L14.25 6l1.036-.259a3.375 3.375 0 002.455-2.456L18 2.25l.259 1.035a3.375 3.375 0 002.456 2.456L21.75 6l-1.035.259a3.375 3.375 0 00-2.456 2.456zM16.894 20.567L16.5 21.75l-.394-1.183a2.25 2.25 0 00-1.423-1.423L13.5 18.75l1.183-.394a2.25 2.25 0 001.423-1.423l.394-1.183.394 1.183a2.25 2.25 0 001.423 1.423l1.183.394-1.183.394a2.25 2.25 0 00-1.423 1.423z" /></svg>,
      meta: "Analyse de Sources & Audio"
    },
    {
      title: "Observatoire Géo-politique",
      desc: "Analyse en temps réel des relations internationales et des enjeux de souveraineté.",
      view: AppView.NEWS_ANALYZER,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" /></svg>,
      meta: "Analyse conjoncturelle"
    },
    {
      title: "Architecte de Dissertation",
      desc: "Outil d'aide à la structuration logique et à la construction de problématiques.",
      view: AppView.ESSAY_ARCHITECT,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M16.862 4.487l1.687-1.688a1.875 1.875 0 112.652 2.652L10.582 16.07a4.5 4.5 0 01-1.897 1.13L6 18l.8-2.685a4.5 4.5 0 011.13-1.897l8.932-8.931zm0 0L19.5 7.125M18 14v4.75A2.25 2.25 0 0115.75 21H5.25A2.25 2.25 0 013 18.75V8.25A2.25 2.25 0 015.25 6H10" /></svg>,
      meta: "Méthodologie formelle"
    },
    {
      title: "Tuteur Intelligent",
      desc: "Posez vos questions librement à une IA spécialisée pour de l'aide immédiate.",
      view: AppView.TUTOR,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M4.26 10.147a60.436 60.436 0 00-.491 6.347A48.627 48.627 0 0112 20.904a48.627 48.627 0 018.232-4.41 60.46 60.46 0 00-.491-6.347m-15.482 0a50.57 50.57 0 00-2.658-.813A59.905 59.905 0 0112 3.493a59.902 59.902 0 0110.499 5.221 69.154 69.154 0 01-1.929.877m-18.029-.206a48.427 48.427 0 016.414-2.584c3.356-1.066 6.975-1.066 10.33 0 2.238.71 4.39 1.584 6.415 2.584m.002.005C21.418 11.232 20 13.974 20 17.069C20 19.533 18.23 21.6 15.823 22.044A48.672 48.672 0 0112 22.25c-2.31 0-4.577-.18-6.768-.523C2.825 21.36 1.25 19.22 1.25 16.897c0-2.903 1.257-5.516 3.255-7.397L4.26 10.147z" /></svg>,
      meta: "Assistance rapide"
    },
    {
      title: "Atelier de Rédaction",
      desc: "Correction de l'orthographe et humanisation du style pour des textes plus fluides.",
      view: AppView.TEXT_REFINER,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M10.5 21l5.25-11.25L21 21m-9-3h7.5M3 5.621a48.474 48.474 0 016-.371m0 0c1.12 0 2.233.038 3.334.114M9 5.25V3m3.334 2.364C11.176 10.658 7.69 15.08 3 17.502m9.334-12.138c.896.061 1.785.147 2.666.257m-4.589 8.495a18.023 18.023 0 01-3.827-5.802" /></svg>,
      meta: "Correction & Style"
    },
    {
      title: "Séminaire Interactif",
      desc: "Discussion assistée par IA sur les concepts de pouvoir, de citoyenneté et de gouvernance.",
      view: AppView.LIVE_SEMINAR,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M12 18.75a6 6 0 006-6v-1.5m-6 7.5a6 6 0 01-6-6v-1.5m6 7.5v3.75m-3.75 0h7.5M12 15.75a3 3 0 01-3-3V4.5a3 3 0 116 0v8.25a3 3 0 01-3 3z" /></svg>,
      meta: "Entraînement au débat"
    },
    {
      title: "Dépôt Numérique",
      desc: "Accès centralisé à vos documents Google Drive et ressources bibliographiques.",
      view: AppView.DRIVE,
      icon: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1} stroke="currentColor" className="w-12 h-12"><path strokeLinecap="round" strokeLinejoin="round" d="M2.25 15.75l5.159-5.159a2.25 2.25 0 013.182 0l5.159 5.159m-1.5-1.5l1.409-1.409a2.25 2.25 0 013.182 0l2.909 2.909m-18 3.75h16.5a1.5 1.5 0 001.5-1.5V6a1.5 1.5 0 00-1.5-1.5H3.75A1.5 1.5 0 002.25 6v12a1.5 1.5 0 001.5 1.5zm10.5-11.25h.008v.008h-.008V8.25zm.375 0a.375.375 0 11-.75 0 .375.375 0 01.75 0z" /></svg>,
      meta: "Cloud & Archives"
    }
  ];

  return (
    <div className="space-y-12 animate-fadeIn py-4">
      <header className="flex flex-col md:flex-row md:items-center justify-between gap-6 border-b border-slate-200 pb-10">
        <div className="space-y-2">
          <div className="flex items-center space-x-2 text-[#003399] text-[10px] font-black uppercase tracking-widest">
            <img 
              src="https://upload.wikimedia.org/wikipedia/commons/5/5f/Flag_of_Quebec.svg" 
              alt="Québec" 
              className="w-6 h-auto shadow-sm border border-black/5"
            />
            <span>Académie du Garage • Québec</span>
          </div>
          <h2 className="text-5xl font-bold text-slate-900 serif tracking-tight">
            Espace de Recherche
          </h2>
          <p className="text-slate-500 font-medium italic">
            "Savoir pour prévoir, afin de pouvoir." — Auguste Comte
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
           <button
            onClick={onShowInstall}
            className="flex items-center space-x-2 px-4 py-3 bg-emerald-50 text-emerald-700 border border-emerald-200 rounded-xl hover:bg-emerald-100 transition-colors shadow-sm"
          >
            <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5">
              <path strokeLinecap="round" strokeLinejoin="round" d="M10.5 1.5H8.25A2.25 2.25 0 006 3.75v16.5a2.25 2.25 0 002.25 2.25h7.5A2.25 2.25 0 0018 20.25V3.75a2.25 2.25 0 00-2.25-2.25H13.5m-3 0V3h3V1.5m-3 0h3m-3 18.75h3" />
            </svg>
            <span className="text-xs font-bold uppercase tracking-widest hidden md:inline">Installer l'App</span>
          </button>

          <div className="flex items-center space-x-4 px-6 py-4 bg-white border border-slate-200 rounded-xl institutional-shadow">
            <div className="w-12 h-12 rounded-lg bg-[#002147] flex items-center justify-center text-xl font-bold text-white">
              {user.pseudonym.charAt(0).toUpperCase()}
            </div>
          </div>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {cards.map((card, idx) => (
          <button
            key={idx}
            onClick={() => onNavigate(card.view)}
            className="group relative p-8 bg-white border border-slate-200 rounded-2xl text-left transition-all hover:border-[#003399] hover:shadow-lg flex flex-col h-full"
          >
            <div className="flex justify-between items-start mb-6">
              <span className="text-slate-400 group-hover:text-[#003399] transition-colors">{card.icon}</span>
              <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">{card.meta}</span>
            </div>
            <h3 className="text-2xl font-bold mb-3 serif group-hover:text-[#003399] transition-colors">{card.title}</h3>
            <p className="text-slate-500 text-sm leading-relaxed mb-8 flex-1">{card.desc}</p>
            <div className="flex items-center text-[#003399] text-xs font-bold uppercase tracking-widest opacity-0 group-hover:opacity-100 transition-opacity">
              <span>Accéder au module</span>
              <svg className="w-4 h-4 ml-2" fill="none" stroke="currentColor" viewBox="0 0 24 24"><path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M14 5l7 7m0 0l-7 7m7-7H3" /></svg>
            </div>
          </button>
        ))}
      </div>

      <div className="bg-[#002147] text-white p-12 rounded-2xl relative overflow-hidden">
        <div className="absolute top-0 right-0 p-8 opacity-10 pointer-events-none serif">
          <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={0.5} stroke="currentColor" className="w-64 h-64"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" /></svg>
        </div>
        <div className="relative z-10 max-w-2xl space-y-6">
          <h4 className="text-blue-300 font-bold uppercase tracking-widest text-xs">Pensée Politique Contemporaine</h4>
          <p className="text-2xl serif italic leading-relaxed">
            "La politique est l'art de concilier le possible avec le nécessaire, dans l'intérêt de la collectivité."
          </p>
          <div className="pt-4 border-t border-white/10 w-48">
            <p className="text-xs font-bold uppercase tracking-widest text-blue-200">Archives de l'Académie</p>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
