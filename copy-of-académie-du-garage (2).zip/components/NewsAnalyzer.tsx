
import React, { useState } from 'react';
import { GoogleGenAI } from "@google/genai";
import { GroundingChunk } from '../types';

const NewsAnalyzer: React.FC = () => {
  const [topic, setTopic] = useState('');
  const [analysis, setAnalysis] = useState('');
  const [sources, setSources] = useState<GroundingChunk[]>([]);
  const [loading, setLoading] = useState(false);

  const analyzeNews = async () => {
    if (!topic) return;
    setLoading(true);
    setAnalysis(''); 
    setSources([]); 
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: "gemini-3-pro-preview",
        contents: `En tant qu'analyste senior en sciences politiques, analyse l'actualité suivante : "${topic}". 
        Identifie les acteurs clés, les enjeux de souveraineté, et lie l'événement à au moins une théorie classique (Réalisme, Libéralisme, etc.). 
        Utilise les informations les plus récentes disponibles via Google Search. Réponds en Français de manière structurée.`,
        config: {
          tools: [{ googleSearch: {} }],
          thinkingConfig: { thinkingBudget: 12000 },
          maxOutputTokens: 16000
        },
      });

      setAnalysis(response.text || "");
      const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
      setSources(chunks as GroundingChunk[]);
    } catch (error) {
      console.error(error);
      setAnalysis("Une erreur est survenue lors de l'analyse. Veuillez vérifier votre clé API.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="space-y-8 animate-fadeIn">
      {/* Hero Section */}
      <div className="bg-slate-900 text-white p-10 rounded-[2.5rem] shadow-2xl overflow-hidden relative group">
        <div className="absolute inset-0 bg-gradient-to-br from-emerald-600/20 via-transparent to-transparent opacity-50"></div>
        <div className="relative z-10">
          <div className="inline-flex items-center space-x-2 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-[10px] font-black uppercase tracking-widest mb-4">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-500 animate-pulse"></span>
            <span>Module d'Analyse Temps Réel</span>
          </div>
          <h2 className="text-4xl font-bold mb-3 serif">Observatoire Géo-politique</h2>
          <p className="text-slate-400 mb-8 text-lg font-medium max-w-2xl leading-relaxed">
            Déchiffrez les rapports de force mondiaux en connectant l'actualité brute aux paradigmes universitaires.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4">
            <input
              type="text"
              className="flex-1 p-5 bg-slate-800/50 backdrop-blur-md border border-slate-700 rounded-2xl outline-none focus:ring-2 focus:ring-emerald-500 text-white transition-all text-lg shadow-inner"
              placeholder="Ex: Tensions en Mer de Chine méridionale..."
              value={topic}
              onChange={(e) => setTopic(e.target.value)}
              onKeyDown={(e) => e.key === 'Enter' && analyzeNews()}
            />
            <button
              onClick={analyzeNews}
              disabled={loading}
              className="bg-emerald-500 hover:bg-emerald-400 text-slate-950 px-10 py-5 rounded-2xl font-black text-lg transition-all shadow-xl shadow-emerald-500/20 disabled:opacity-50 flex items-center justify-center min-w-[280px] active:scale-95"
            >
              {loading ? (
                <>
                  <svg className="animate-spin -ml-1 mr-3 h-6 w-6 text-slate-950" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                  </svg>
                  Réflexion en cours...
                </>
              ) : 'Lancer l\'Investigation'}
            </button>
          </div>
        </div>
        <div className="absolute top-0 right-0 p-12 opacity-[0.05] pointer-events-none group-hover:rotate-12 transition-transform duration-1000">
           <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={0.5} stroke="currentColor" className="w-64 h-64"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" /></svg>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
        {/* Main Analysis Area */}
        <div className="lg:col-span-8 space-y-8">
          {loading && (
            <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 animate-pulse space-y-8">
              <div className="h-10 bg-slate-100 rounded-full w-2/3"></div>
              <div className="space-y-4">
                <div className="h-4 bg-slate-50 rounded w-full"></div>
                <div className="h-4 bg-slate-50 rounded w-full"></div>
                <div className="h-4 bg-slate-50 rounded w-4/5"></div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="h-32 bg-slate-50 rounded-3xl"></div>
                <div className="h-32 bg-slate-50 rounded-3xl"></div>
              </div>
            </div>
          )}

          {analysis && (
            <div className="bg-white p-10 rounded-[2.5rem] shadow-sm border border-slate-100 animate-fadeIn relative overflow-hidden">
              <div className="absolute top-0 right-0 w-32 h-32 bg-emerald-500/5 rounded-bl-[5rem]"></div>
              <h3 className="text-2xl font-bold mb-8 serif text-slate-800 flex items-center">
                <span className="w-10 h-10 rounded-xl bg-emerald-100 text-emerald-600 flex items-center justify-center mr-4 text-xl shadow-sm">
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                </span>
                Synthèse Académique
              </h3>
              <div className="text-slate-700 whitespace-pre-wrap leading-relaxed font-medium text-lg first-letter:text-4xl first-letter:font-bold first-letter:serif first-letter:text-emerald-600 first-letter:mr-2">
                {analysis}
              </div>
              <div className="mt-12 pt-8 border-t border-slate-50 flex items-center justify-between text-[10px] font-black uppercase tracking-widest text-slate-400">
                <span>Généré via Gemini 3 Pro</span>
                <span className="text-emerald-500">Document Certifié</span>
              </div>
            </div>
          )}
        </div>

        {/* Sidebar: Sources & Info */}
        <div className="lg:col-span-4 space-y-8">
          {sources.length > 0 && !loading && (
            <div className="bg-white p-8 rounded-[2.5rem] shadow-sm border border-slate-100 animate-fadeIn">
              <div className="flex items-center justify-between mb-8">
                <h3 className="text-xl font-bold serif text-slate-800">Sources Primaires</h3>
                <span className="px-2 py-1 bg-emerald-100 text-emerald-700 text-[10px] font-bold rounded-lg uppercase tracking-widest">{sources.length} Ref</span>
              </div>
              <div className="space-y-4">
                {sources.map((chunk, i) => chunk.web && (
                  <a
                    key={i}
                    href={chunk.web.uri}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="group block p-5 bg-slate-50 rounded-3xl border border-slate-100 transition-all duration-300 hover:bg-emerald-50 hover:border-emerald-200 hover:shadow-lg hover:-translate-y-1"
                  >
                    <div className="flex items-start justify-between">
                      <div className="w-10 h-10 rounded-xl bg-white border border-slate-200 flex items-center justify-center text-lg shadow-sm group-hover:bg-emerald-500 group-hover:text-white transition-colors duration-300">
                        <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m0 12.75h7.5m-7.5 3H12M10.5 2.25H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                      </div>
                      <div className="text-emerald-300 group-hover:text-emerald-500 transition-colors">
                        <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                        </svg>
                      </div>
                    </div>
                    <div className="mt-4">
                      <p className="text-sm font-bold text-slate-800 leading-tight group-hover:text-emerald-900 transition-colors">{chunk.web.title}</p>
                      <p className="text-[10px] text-slate-400 truncate mt-2 font-mono group-hover:text-emerald-600 transition-colors">{chunk.web.uri}</p>
                    </div>
                    <div className="mt-4 pt-3 border-t border-slate-100 opacity-0 group-hover:opacity-100 transition-opacity flex items-center space-x-2">
                      <span className="text-[10px] font-black text-emerald-600 uppercase tracking-widest">Consulter l'article</span>
                      <span className="w-4 h-px bg-emerald-200"></span>
                    </div>
                  </a>
                ))}
              </div>
            </div>
          )}

          <div className="bg-slate-900 text-white p-8 rounded-[2.5rem] shadow-xl relative overflow-hidden group">
            <div className="absolute inset-0 bg-emerald-500/10 group-hover:bg-emerald-500/20 transition-colors duration-500"></div>
            <h3 className="text-xl font-bold mb-4 serif relative z-10 flex items-center">
              <span className="mr-3 text-2xl">🧠</span> Note de Rigueur
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed font-medium relative z-10">
              L'IA mobilise ici sa capacité de <span className="text-emerald-400 font-bold italic">Deep Thinking</span> combinée à la puissance de Google Search pour filtrer la désinformation et extraire les racines structurelles de l'actualité.
            </p>
            <div className="mt-6 flex items-center space-x-3 relative z-10">
              <div className="h-1 flex-1 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full w-full bg-emerald-500 animate-[shimmer_2s_infinite]"></div>
              </div>
              <span className="text-[10px] font-black uppercase text-emerald-500 tracking-widest">Grounding Actif</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default NewsAnalyzer;
