
import React, { useState, useEffect } from 'react';
import { GoogleGenAI, Type } from "@google/genai";
import { TheoryAnalysis, TheoryComparison } from '../types';

interface QuizQuestion {
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
}

const TheoryExplorer: React.FC = () => {
  const [query, setQuery] = useState('');
  const [analysis, setAnalysis] = useState<TheoryAnalysis | null>(null);
  const [comparison, setComparison] = useState<TheoryComparison | null>(null);
  const [loading, setLoading] = useState(false);
  const [quizLoading, setQuizLoading] = useState(false);
  const [quiz, setQuiz] = useState<QuizQuestion[] | null>(null);
  const [userAnswers, setUserAnswers] = useState<{[key: number]: number}>({});
  const [showResults, setShowResults] = useState(false);
  
  const [favorites, setFavorites] = useState<TheoryAnalysis[]>([]);
  const [activeTab, setActiveTab] = useState<'pure' | 'figures' | 'praxis'>('pure');
  const [comparisonQueue, setComparisonQueue] = useState<TheoryAnalysis[]>([]);

  useEffect(() => {
    const saved = localStorage.getItem('agora_theory_favorites');
    if (saved) {
      try {
        setFavorites(JSON.parse(saved));
      } catch (e) {
        console.error("Erreur de chargement des favoris", e);
      }
    }
  }, []);

  const toggleFavorite = (theory: TheoryAnalysis) => {
    const exists = favorites.find(f => f.concept === theory.concept);
    let newFavorites;
    
    if (exists) {
      newFavorites = favorites.filter(f => f.concept !== theory.concept);
    } else {
      newFavorites = [theory, ...favorites];
    }
    
    setFavorites(newFavorites);
    localStorage.setItem('agora_theory_favorites', JSON.stringify(newFavorites));
  };

  const isFavorite = (theory: TheoryAnalysis) => {
    return favorites.some(f => f.concept === theory.concept);
  };

  const deleteFavorite = (e: React.MouseEvent, concept: string) => {
    e.stopPropagation();
    if(confirm(`Supprimer "${concept}" des archives ?`)) {
      const newFavorites = favorites.filter(f => f.concept !== concept);
      setFavorites(newFavorites);
      localStorage.setItem('agora_theory_favorites', JSON.stringify(newFavorites));
    }
  };

  const handleSearch = async (searchTerm?: string) => {
    const finalQuery = searchTerm || query;
    if (!finalQuery) return;
    
    setLoading(true);
    setAnalysis(null);
    setComparison(null);
    setQuiz(null);
    setUserAnswers({});
    setShowResults(false);
    setActiveTab('pure');
    
    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `En tant que directeur de recherche à l'Académie du Garage, analyse de manière académique et exhaustive le concept politique suivant : "${finalQuery}". 
        Produis une exégèse rigoureuse incluant les auteurs fondamentaux, les débats contemporains et les limites théoriques. 
        Le ton doit être formel, précis et encyclopédique.`,
        config: {
          responseMimeType: "application/json",
          thinkingConfig: { thinkingBudget: 16000 },
          maxOutputTokens: 20000,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              concept: { type: Type.STRING },
              definition: { type: Type.STRING },
              keyFigures: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    name: { type: Type.STRING },
                    contribution: { type: Type.STRING },
                    work: { type: Type.STRING }
                  },
                  required: ["name", "contribution", "work"]
                }
              },
              historicalContext: { type: Type.STRING },
              modernApplication: { type: Type.STRING },
              criticalAnalysis: { type: Type.STRING }
            },
            required: ["concept", "definition", "keyFigures", "historicalContext", "modernApplication", "criticalAnalysis"]
          }
        }
      });

      if (response.text) {
        setAnalysis(JSON.parse(response.text));
      }
    } catch (error) {
      console.error(error);
      alert("Une erreur de communication avec le serveur de recherche est survenue. Vérifiez votre clé API.");
    } finally {
      setLoading(false);
    }
  };

  const generateQuiz = async () => {
    if (!analysis) return;
    setQuizLoading(true);
    setQuiz(null);
    setUserAnswers({});
    setShowResults(false);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-flash-preview',
        contents: `Génère un quiz QCM de 3 questions pointues pour vérifier la compréhension du concept : "${analysis.concept}".
        Les questions doivent porter sur la définition, un auteur clé, et une nuance critique.`,
        config: {
          responseMimeType: "application/json",
          responseSchema: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                question: { type: Type.STRING },
                options: { type: Type.ARRAY, items: { type: Type.STRING } },
                correctIndex: { type: Type.INTEGER },
                explanation: { type: Type.STRING }
              },
              required: ["question", "options", "correctIndex", "explanation"]
            }
          }
        }
      });
      if(response.text) {
        setQuiz(JSON.parse(response.text));
      }
    } catch (e) {
      console.error(e);
      alert("Erreur lors de la génération du quiz.");
    } finally {
      setQuizLoading(false);
    }
  };

  const handleCompare = async () => {
    if (comparisonQueue.length !== 2) return;
    setLoading(true);
    setAnalysis(null);
    setComparison(null);
    setQuiz(null);

    try {
      const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
      const response = await ai.models.generateContent({
        model: 'gemini-3-pro-preview',
        contents: `Produis un rapport comparatif critique entre : "${comparisonQueue[0].concept}" et "${comparisonQueue[1].concept}". 
        Le rapport doit suivre une structure académique stricte (convergences, divergences, synthèse prospective).`,
        config: {
          responseMimeType: "application/json",
          thinkingConfig: { thinkingBudget: 16000 },
          maxOutputTokens: 20000,
          responseSchema: {
            type: Type.OBJECT,
            properties: {
              theoryA: { type: Type.STRING },
              theoryB: { type: Type.STRING },
              convergencePoints: { type: Type.ARRAY, items: { type: Type.STRING } },
              divergencePoints: {
                type: Type.ARRAY,
                items: {
                  type: Type.OBJECT,
                  properties: {
                    aspect: { type: Type.STRING },
                    theoryA_view: { type: Type.STRING },
                    theoryB_view: { type: Type.STRING }
                  }
                }
              },
              synthesis: { type: Type.STRING },
              comparativeConclusion: { type: Type.STRING }
            },
            required: ["theoryA", "theoryB", "convergencePoints", "divergencePoints", "synthesis", "comparativeConclusion"]
          }
        }
      });

      if (response.text) {
        setComparison(JSON.parse(response.text));
      }
    } catch (error) {
      console.error(error);
      alert("Erreur lors de la génération du rapport comparatif.");
    } finally {
      setLoading(false);
    }
  };

  const exportToMarkdown = (theory: TheoryAnalysis) => {
    let md = `# Rapport d'Analyse Théorique : ${theory.concept}\n\n`;
    md += `*Établi par l'unité de recherche de l'Académie du Garage*\n`;
    md += `*Généré le : ${new Date().toLocaleDateString('fr-FR')}*\n\n`;
    md += `## Définition et Ontologie\n\n${theory.definition}\n\n`;
    md += `## Contexte Historique et Épistémologique\n\n${theory.historicalContext}\n\n`;
    md += `## Références Académiques Majeures\n\n`;
    theory.keyFigures.forEach(f => {
      md += `### ${f.name}\n- **Ouvrage :** *${f.work}*\n- **Contribution :** ${f.contribution}\n\n`;
    });
    md += `## Applications Contemporaines (Praxis)\n\n${theory.modernApplication}\n\n`;
    md += `## Analyse Critique et Limites du Modèle\n\n${theory.criticalAnalysis}\n\n`;

    const blob = new Blob([md], { type: 'text/markdown' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `rapport_${theory.concept.toLowerCase().replace(/\s+/g, '_')}.md`;
    a.click();
    URL.revokeObjectURL(url);
  };

  const addToComparison = (theory: TheoryAnalysis) => {
    if (comparisonQueue.find(t => t.concept === theory.concept)) {
      setComparisonQueue(comparisonQueue.filter(t => t.concept !== theory.concept));
      return;
    }
    if (comparisonQueue.length >= 2) return;
    setComparisonQueue([...comparisonQueue, theory]);
  };

  return (
    <div className="space-y-10 animate-fadeIn py-2">
      {/* Search Module - Academic Bar */}
      <div className="bg-white p-10 border border-slate-200 rounded-2xl shadow-sm">
        <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 mb-8">
          <div className="flex items-center space-x-4">
            <div className="w-12 h-12 bg-[#002147] text-white rounded-lg flex items-center justify-center shadow-inner">
               <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-6 h-6"><path strokeLinecap="round" strokeLinejoin="round" d="M12 6.042A8.967 8.967 0 006 3.75c-1.052 0-2.062.18-3 .512v14.25A8.987 8.987 0 016 18c2.305 0 4.408.867 6 2.292m0-14.25a8.966 8.966 0 016-2.292c1.052 0 2.062.18 3 .512v14.25A8.987 8.987 0 0018 18a8.967 8.967 0 00-6 2.292m0-14.25v14.25" /></svg>
            </div>
            <div>
              <h2 className="text-2xl font-bold text-slate-900 serif">Codex de l'Exégèse</h2>
              <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Base de données théorique de l'Académie</p>
            </div>
          </div>

          {comparisonQueue.length > 0 && (
            <div className="flex items-center space-x-3 bg-slate-50 p-2 rounded-xl border border-slate-200">
              <div className="flex -space-x-2">
                {comparisonQueue.map((t, i) => (
                  <div key={i} className="w-8 h-8 rounded-full bg-[#003399] border-2 border-white flex items-center justify-center text-[10px] text-white font-bold" title={t.concept}>
                    {t.concept.charAt(0)}
                  </div>
                ))}
              </div>
              <button 
                onClick={handleCompare}
                disabled={comparisonQueue.length !== 2}
                className="text-[10px] font-bold uppercase tracking-widest px-4 py-2 bg-[#002147] text-white rounded-lg disabled:opacity-30 transition-all"
              >
                Rapport Comparatif
              </button>
              <button onClick={() => setComparisonQueue([])} className="text-slate-400 hover:text-red-600 text-xs px-2">Annuler</button>
            </div>
          )}
        </div>
        
        <div className="flex gap-4">
          <input
            type="text"
            className="flex-1 p-4 bg-slate-50 border border-slate-200 rounded-xl outline-none focus:ring-1 focus:ring-[#002147] focus:bg-white transition-all text-sm font-medium"
            placeholder="Rechercher un concept, une idéologie ou un paradigme..."
            value={query}
            onChange={(e) => setQuery(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && handleSearch()}
          />
          <button
            onClick={() => handleSearch()}
            disabled={loading}
            className="bg-[#002147] text-white px-8 py-4 rounded-xl font-bold text-sm hover:bg-black transition-all flex items-center space-x-2 disabled:opacity-50"
          >
            {loading ? <span className="animate-pulse">Analyse...</span> : "Rechercher"}
          </button>
        </div>
      </div>

      {loading && (
        <div className="flex flex-col items-center justify-center py-20 space-y-4">
          <div className="w-10 h-10 border-2 border-[#002147] border-t-transparent rounded-full animate-spin"></div>
          <p className="text-slate-400 font-bold text-xs uppercase tracking-widest italic">Interrogation des archives...</p>
        </div>
      )}

      {/* RESULT VIEW */}
      {analysis && !loading && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          <div className="lg:col-span-8 bg-white border border-slate-200 rounded-2xl overflow-hidden shadow-sm">
            <div className="p-8 bg-[#f8fafc] border-b border-slate-200 flex justify-between items-start">
              <div className="space-y-1">
                <span className="text-[10px] font-black text-[#003399] uppercase tracking-widest">Notice Documentaire</span>
                <h3 className="text-4xl font-bold serif text-slate-900 leading-tight">{analysis.concept}</h3>
              </div>
              <div className="flex space-x-2">
                <button 
                  onClick={() => toggleFavorite(analysis)}
                  className={`p-3 border rounded-lg transition-all shadow-sm ${isFavorite(analysis) ? 'bg-amber-400 text-white border-amber-500' : 'bg-white border-slate-200 text-slate-400 hover:text-amber-500'}`}
                  title={isFavorite(analysis) ? "Retirer des archives" : "Ajouter aux archives"}
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill={isFavorite(analysis) ? "currentColor" : "none"} viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M11.48 3.499a.562.562 0 011.04 0l2.125 5.111a.563.563 0 00.475.345l5.518.442c.545.044.77.77.326 1.163l-4.304 3.86a.562.562 0 00-.182.557l1.285 5.385a.562.562 0 01-.84.61l-4.725-2.885a.563.563 0 00-.586 0L6.982 20.54a.562.562 0 01-.84-.61l1.285-5.386a.562.562 0 00-.182-.557l-4.304-3.86a.562.562 0 01.326-1.163l5.518-.442a.563.563 0 00.475-.345L11.48 3.5z" /></svg>
                </button>
                <button 
                  onClick={() => exportToMarkdown(analysis)} 
                  className="p-3 bg-white border border-slate-200 rounded-lg hover:bg-slate-50 transition-colors shadow-sm"
                  title="Exporter en Markdown"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M19.5 14.25v-2.625a3.375 3.375 0 00-3.375-3.375h-1.5A1.125 1.125 0 0113.5 7.125v-1.5a3.375 3.375 0 00-3.375-3.375H8.25m2.25 0H5.625c-.621 0-1.125.504-1.125 1.125v17.25c0 .621.504 1.125 1.125 1.125h12.75c.621 0 1.125-.504 1.125-1.125V11.25a9 9 0 00-9-9z" /></svg>
                </button>
                <button 
                  onClick={() => addToComparison(analysis)}
                  className={`p-3 border rounded-lg transition-all shadow-sm ${comparisonQueue.some(t => t.concept === analysis.concept) ? 'bg-[#003399] text-white border-[#003399]' : 'bg-white border-slate-200 text-slate-400 hover:text-[#002147]'}`}
                  title="Comparer"
                >
                  <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-5 h-5"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A5.974 5.974 0 0115.75 6a5.974 5.974 0 01-3-3 5.974 5.974 0 01-3 3 5.974 5.974 0 01-3-3M6.75 6.75A2.25 2.25 0 019 9v.75a2.25 2.25 0 01-2.25 2.25h-.75a2.25 2.25 0 01-2.25-2.25V9a2.25 2.25 0 012.25-2.25h.75zm0 0V3.75m12-3v3m0 0v.75a2.25 2.25 0 01-2.25 2.25h-.75a2.25 2.25 0 01-2.25-2.25V6.75a2.25 2.25 0 012.25-2.25h.75z" /></svg>
                </button>
              </div>
            </div>

            <div className="flex bg-white border-b border-slate-100">
              {[
                { id: 'pure', label: 'Ontologie' },
                { id: 'figures', label: 'Autorités' },
                { id: 'praxis', label: 'Praxis' }
              ].map(tab => (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`flex-1 py-4 px-2 text-[10px] font-bold uppercase tracking-widest transition-all border-b-2 ${
                    activeTab === tab.id 
                    ? 'border-[#002147] text-[#002147]' 
                    : 'border-transparent text-slate-400 hover:text-slate-600 hover:bg-slate-50'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>

            <div className="p-10 space-y-10 text-justify-academic">
              {activeTab === 'pure' && (
                <div className="space-y-10 animate-fadeIn">
                  <section>
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#003399] mb-4">Définition & Précision Conceptuelle</h4>
                    <p className="text-xl text-slate-800 leading-relaxed font-medium serif italic">
                      {analysis.definition}
                    </p>
                  </section>
                  <section className="pt-8 border-t border-slate-100">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-400 mb-4">Contexte Épistémologique</h4>
                    <p className="text-slate-600 leading-relaxed text-sm">{analysis.historicalContext}</p>
                  </section>
                </div>
              )}

              {activeTab === 'figures' && (
                <div className="space-y-8 animate-fadeIn">
                  <h4 className="text-[10px] font-bold uppercase tracking-widest text-[#003399] mb-4">Principales Contributions Académiques</h4>
                  <div className="grid grid-cols-1 gap-6">
                    {analysis.keyFigures.map((figure, i) => (
                      <div key={i} className="p-6 border border-slate-100 rounded-xl bg-slate-50/50">
                        <div className="flex justify-between items-start mb-2">
                          <p className="font-bold text-lg text-[#002147] serif">{figure.name}</p>
                          <span className="text-[10px] font-bold text-slate-400 italic">Ouvrage de référence</span>
                        </div>
                        <p className="text-xs font-bold text-[#003399] italic mb-3">"{figure.work}"</p>
                        <p className="text-slate-600 text-sm leading-relaxed">{figure.contribution}</p>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {activeTab === 'praxis' && (
                <div className="space-y-10 animate-fadeIn">
                  <section className="bg-[#002147] text-white p-8 rounded-xl shadow-inner">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-blue-300 mb-4">Application Contemporaine</h4>
                    <p className="text-base leading-relaxed">{analysis.modernApplication}</p>
                  </section>
                  <section className="p-8 border-l-4 border-slate-200 bg-slate-50">
                    <h4 className="text-[10px] font-bold uppercase tracking-widest text-slate-500 mb-4">Analyse Critique & Limites</h4>
                    <p className="text-slate-800 leading-relaxed font-bold italic serif">{analysis.criticalAnalysis}</p>
                  </section>
                </div>
              )}
            </div>
          </div>

          <div className="lg:col-span-4 space-y-6">
            {/* QUIZ MODULE */}
            <div className="bg-white p-6 border border-slate-200 rounded-xl shadow-sm">
              <div className="flex justify-between items-center mb-4 pb-4 border-b border-slate-100">
                <h4 className="text-sm font-bold serif text-slate-900">Auto-Évaluation</h4>
                {!quiz ? (
                  <button 
                    onClick={generateQuiz}
                    disabled={quizLoading}
                    className="text-[10px] font-bold uppercase tracking-widest bg-emerald-100 text-emerald-700 px-3 py-1 rounded-full hover:bg-emerald-200 transition-colors disabled:opacity-50"
                  >
                    {quizLoading ? "Génération..." : "Lancer le Quiz"}
                  </button>
                ) : (
                  <button 
                    onClick={() => { setQuiz(null); setUserAnswers({}); setShowResults(false); }}
                    className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-slate-600"
                  >
                    Fermer
                  </button>
                )}
              </div>
              
              {quiz && (
                <div className="space-y-6 animate-fadeIn">
                  {quiz.map((q, idx) => (
                    <div key={idx} className="space-y-2">
                      <p className="text-xs font-bold text-slate-800">{idx + 1}. {q.question}</p>
                      <div className="space-y-1">
                        {q.options.map((opt, optIdx) => {
                          const isSelected = userAnswers[idx] === optIdx;
                          const isCorrect = q.correctIndex === optIdx;
                          let btnClass = "w-full text-left p-2 rounded-lg text-xs border transition-all ";
                          
                          if (showResults) {
                            if (isCorrect) btnClass += "bg-emerald-100 border-emerald-300 text-emerald-800 font-bold";
                            else if (isSelected && !isCorrect) btnClass += "bg-red-50 border-red-200 text-red-800 opacity-50";
                            else btnClass += "bg-slate-50 border-slate-100 text-slate-400 opacity-50";
                          } else {
                            if (isSelected) btnClass += "bg-[#002147] text-white border-[#002147]";
                            else btnClass += "bg-white border-slate-200 text-slate-600 hover:bg-slate-50";
                          }

                          return (
                            <button
                              key={optIdx}
                              disabled={showResults}
                              onClick={() => setUserAnswers({...userAnswers, [idx]: optIdx})}
                              className={btnClass}
                            >
                              {opt}
                            </button>
                          );
                        })}
                      </div>
                      {showResults && (
                         <p className="text-[10px] text-emerald-600 italic bg-emerald-50 p-2 rounded border border-emerald-100">
                           💡 {q.explanation}
                         </p>
                      )}
                    </div>
                  ))}
                  
                  {!showResults ? (
                    <button 
                      onClick={() => setShowResults(true)}
                      disabled={Object.keys(userAnswers).length !== quiz.length}
                      className="w-full py-2 bg-slate-900 text-white rounded-lg text-xs font-bold uppercase tracking-widest disabled:opacity-50"
                    >
                      Vérifier mes réponses
                    </button>
                  ) : (
                    <div className="text-center">
                       <p className="text-xs font-bold text-slate-900 mb-2">
                         Score : {Object.keys(userAnswers).filter(k => userAnswers[parseInt(k)] === quiz[parseInt(k)].correctIndex).length} / {quiz.length}
                       </p>
                       <button onClick={generateQuiz} className="text-xs text-[#003399] underline">Nouveau Quiz</button>
                    </div>
                  )}
                </div>
              )}
              
              {!quiz && !quizLoading && (
                 <p className="text-xs text-slate-400 italic text-center py-4">
                   Testez votre compréhension de "{analysis.concept}" en générant un quiz rapide.
                 </p>
              )}
            </div>

            {/* ARCHIVES */}
            <div className="bg-white p-6 border border-slate-200 rounded-xl shadow-sm">
              <h4 className="text-sm font-bold mb-4 serif text-slate-900 border-b border-slate-100 pb-2">
                Archives ({favorites.length})
              </h4>
              <div className="space-y-2 max-h-[300px] overflow-y-auto">
                {favorites.length === 0 ? (
                  <p className="text-[10px] text-slate-400 italic py-4 text-center">Aucune archive. Ajoutez des concepts avec l'étoile.</p>
                ) : (
                  favorites.map((fav, i) => (
                    <div key={i} className="group flex items-center justify-between p-3 rounded-lg hover:bg-slate-50 border border-transparent hover:border-slate-100 transition-colors">
                      <button
                        onClick={() => setAnalysis(fav)}
                        className="text-left text-xs font-medium text-slate-600 hover:text-[#002147] flex-1 truncate"
                      >
                        {fav.concept}
                      </button>
                      <button 
                        onClick={(e) => deleteFavorite(e, fav.concept)}
                        className="text-slate-300 hover:text-red-500 px-2 opacity-0 group-hover:opacity-100 transition-opacity"
                        title="Supprimer"
                      >
                        ×
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* COMPARISON VIEW */}
      {comparison && !loading && (
        <div className="space-y-8 animate-fadeIn">
          <div className="bg-[#002147] text-white p-12 rounded-2xl border border-blue-900/50 shadow-xl">
            <h3 className="text-4xl font-bold serif mb-2">Rapport de Comparaison Critique</h3>
            <p className="text-blue-200 text-sm font-medium border-t border-white/10 pt-4 mt-4 uppercase tracking-widest">
              Confrontation : <span className="text-white font-bold">{comparison.theoryA}</span> vs <span className="text-white font-bold">{comparison.theoryB}</span>
            </p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            <div className="lg:col-span-2 bg-white border border-slate-200 rounded-2xl p-8 shadow-sm">
              <h4 className="text-lg font-bold serif text-[#002147] mb-6 flex items-center">
                <span className="w-8 h-px bg-[#002147] mr-3"></span> Analyse des Divergences
              </h4>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                {comparison.divergencePoints.map((dp, i) => (
                  <div key={i} className="space-y-3 p-6 border border-slate-100 rounded-xl bg-slate-50/30">
                    <p className="text-[10px] font-black uppercase text-slate-400 tracking-widest text-center border-b border-slate-100 pb-2">{dp.aspect}</p>
                    <div className="space-y-4">
                      <div>
                        <p className="text-[9px] font-bold text-[#003399] uppercase mb-1">{comparison.theoryA}</p>
                        <p className="text-sm italic leading-relaxed text-slate-700">{dp.theoryA_view}</p>
                      </div>
                      <div className="border-t border-slate-100 pt-2">
                        <p className="text-[9px] font-bold text-slate-600 uppercase mb-1">{comparison.theoryB}</p>
                        <p className="text-sm italic leading-relaxed text-slate-700">{dp.theoryB_view}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded-2xl p-8">
              <h4 className="text-lg font-bold serif text-[#003399] mb-6">Convergences Théoriques</h4>
              <ul className="space-y-4">
                {comparison.convergencePoints.map((point, i) => (
                  <li key={i} className="flex items-start space-x-3 text-sm text-slate-700 leading-relaxed border-l-2 border-[#003399] pl-4">
                    {point}
                  </li>
                ))}
              </ul>
            </div>

            <div className="bg-slate-900 text-white rounded-2xl p-8 border border-slate-800 shadow-2xl">
              <h4 className="text-lg font-bold serif text-blue-400 mb-6">Synthèse Prospective</h4>
              <p className="text-lg serif italic leading-relaxed text-slate-300">
                {comparison.synthesis}
              </p>
              <div className="mt-8 pt-6 border-t border-slate-800 text-xs text-slate-500 font-medium">
                {comparison.comparativeConclusion}
              </div>
            </div>
          </div>
          
          <div className="flex justify-center pt-6">
            <button 
              onClick={() => {setComparison(null); setComparisonQueue([]);}}
              className="text-[10px] font-bold uppercase tracking-widest text-slate-400 hover:text-[#002147] transition-colors"
            >
              Archiver et fermer le rapport
            </button>
          </div>
        </div>
      )}

      {/* WELCOME VIEW */}
      {!analysis && !comparison && !loading && (
        <div className="space-y-12 py-10">
          <div className="text-center max-w-2xl mx-auto space-y-4">
            <h3 className="text-3xl font-bold serif text-slate-900 leading-tight">Index Thématique de l'Académie</h3>
            <p className="text-slate-500 text-sm italic font-medium">Consultez les paradigmes dominants ou soumettez une nouvelle requête exégétique.</p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            {[
              { t: 'Biopolitique', d: 'Michel Foucault', i: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M12 21a9.004 9.004 0 008.716-6.747M12 21a9.004 9.004 0 01-8.716-6.747M12 21c2.485 0 4.5-4.03 4.5-9S14.485 3 12 3m0 18c-2.485 0-4.5-4.03-4.5-9S9.515 3 12 3m0 0a8.997 8.997 0 017.843 4.582M12 3a8.997 8.997 0 00-7.843 4.582m15.686 0A11.953 11.953 0 0112 10.5c-2.998 0-5.74-1.1-7.843-2.918m15.686 0A8.959 8.959 0 0121 12c0 .778-.099 1.533-.284 2.253m0 0A17.919 17.919 0 0112 16.5c-3.162 0-6.133-.815-8.716-2.247m0 0A9.015 9.015 0 013 12c0-1.605.42-3.113 1.157-4.418" /></svg> },
              { t: 'Libéralisme', d: 'Robert Keohane', i: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M12 3v17.25m0 0c-1.472 0-2.882.265-4.185.75M12 20.25c1.472 0 2.882.265 4.185.75M18.75 4.97A5.974 5.974 0 0115.75 6a5.974 5.974 0 01-3-3 5.974 5.974 0 01-3 3 5.974 5.974 0 01-3-3M6.75 6.75A2.25 2.25 0 019 9v.75a2.25 2.25 0 01-2.25 2.25h-.75a2.25 2.25 0 01-2.25-2.25V9a2.25 2.25 0 012.25-2.25h.75zm0 0V3.75m12-3v3m0 0v.75a2.25 2.25 0 01-2.25 2.25h-.75a2.25 2.25 0 01-2.25-2.25V6.75a2.25 2.25 0 012.25-2.25h.75z" /></svg> },
              { t: 'Réalisme', d: 'Kenneth Waltz', i: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M9 12.75l3 3m0 0l3-3m-3 3v-7.5M21 12a9 9 0 11-18 0 9 9 0 0118 0z" /></svg> },
              { t: 'Théorie Critique', d: 'Robert Cox', i: <svg xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" strokeWidth={1.5} stroke="currentColor" className="w-8 h-8"><path strokeLinecap="round" strokeLinejoin="round" d="M15.75 5.25a3 3 0 013 3m3 0a6 6 0 01-7.029 5.912c-.563-.097-1.159.026-1.563.43L10.5 17.25H8.25v2.25H6v2.25H2.25v-2.818c0-.597.237-1.17.659-1.591l6.499-6.499c.404-.404.527-1 .43-1.563A6 6 0 1121.75 8.25z" /></svg> }
            ].map((item, idx) => (
              <button
                key={idx}
                onClick={() => { setQuery(item.t); handleSearch(item.t); }}
                className="bg-white p-6 text-left border border-slate-200 rounded-xl hover:border-[#002147] hover:shadow-md transition-all group"
              >
                <div className="text-slate-400 mb-4 group-hover:text-[#002147] transition-all">{item.i}</div>
                <p className="font-bold text-slate-900 text-xs uppercase tracking-widest">{item.t}</p>
                <p className="text-[10px] text-slate-400 mt-1 font-medium">{item.d}</p>
              </button>
            ))}
          </div>

          {favorites.length > 0 && (
             <div className="max-w-4xl mx-auto mt-12">
               <h4 className="text-center text-xs font-bold uppercase tracking-widest text-slate-400 mb-6">Vos Archives Récentes</h4>
               <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                 {favorites.slice(0, 6).map((fav, i) => (
                   <button
                    key={i}
                    onClick={() => setAnalysis(fav)}
                    className="p-4 bg-slate-50 border border-slate-100 rounded-lg text-sm text-slate-600 hover:bg-white hover:border-slate-300 hover:shadow-sm transition-all text-left truncate"
                   >
                     {fav.concept}
                   </button>
                 ))}
               </div>
             </div>
          )}
        </div>
      )}
    </div>
  );
};

export default TheoryExplorer;
